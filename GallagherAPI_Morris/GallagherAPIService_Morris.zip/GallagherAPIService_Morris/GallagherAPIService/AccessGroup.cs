﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace GallagherAPIService
{
    public class AccessGroup
    {
        static SqlConnection sql = connString.getConnString();
        static string Tower = ConfigurationManager.AppSettings["Tower"].ToString();
        public static async Task<bool> GetaccessGrpchoice()
        {
            Ping ping;
            IPAddress address;
            PingReply pong;
            int countforStop = 0;
            do
            {
                countforStop = countforStop + 1;
                ping = new Ping();
                address = IPAddress.Parse(connString.GAL_Server_IP_address);
                pong = ping.Send(address);
                if (pong.Status == IPStatus.Success)
                {
                    try
                    {
                        //HttpResponseMessage response;
                        //using (Authentication._client())
                        //{
                        //    response = await Authentication._client().GetAsync("/api/access_groups?pos=0&previous=False&top=1000");
                        //}
                        Authentication._client();
                        List<string> checkrepeatedList = new List<string>();
                        //HttpResponseMessage response = await Authentication._client().GetAsync("/api/access_groups?pos=0&previous=False&top=10000");
                        HttpResponseMessage response = await Authentication._client().GetAsync("/api/access_groups?top=1000");
                        if (response.IsSuccessStatusCode)
                        {
                            string result = await response.Content.ReadAsStringAsync();
                            cardholderManagement.logger.Info("Get Access Grp:" + result);
                            var data = JsonConvert.DeserializeObject<AllAccessGrpConfig>(result);
                            foreach (resultsConfig r in data.results)
                            {
                                //if (sql.State == ConnectionState.Closed)
                                //    sql.Open();
                                //using (SqlCommand sqlcmd = new SqlCommand("addAccessGrp", sql))
                                //{
                                //    sqlcmd.CommandType = CommandType.StoredProcedure;
                                //    sqlcmd.Parameters.AddWithValue("@Tower", Tower);
                                //    sqlcmd.Parameters.AddWithValue("@accessGrpName", r.name);
                                //    sqlcmd.Parameters.AddWithValue("@accessGrpID", r.id);
                                //    if (sql.State == ConnectionState.Closed)
                                //        sql.Open();
                                //    SqlCommand sqlcmd2 = new SqlCommand("SELECT count(*) FROM dbo.AccessGrp where accessGrpID = '" + r.id + "' AND Tower = '" + Tower + "'", sql);
                                //    int count = (int)sqlcmd2.ExecuteScalar();
                                //    if (count > 0) { sql.Close(); }
                                //    else
                                //    {
                                //        sqlcmd.ExecuteNonQuery();
                                //    }
                                //}
                                //sql.Close();
                                if (db.HKLandACS.AccessGroup.accessGrpIDExists(r.id, Tower)<= 0)
                                {
                                    db.HKLandACS.AccessGroup.addAccessGrp(Tower, r.name, r.id);
                                }
                                checkrepeatedList.Add(r.id);
                            }
                            //if (sql.State == ConnectionState.Closed)
                            //    sql.Open();
                            //SqlDataAdapter daCheck = new SqlDataAdapter("select accessGrpID FROM dbo.AccessGrp where Tower = '" + Tower + "'", sql);
                            //DataTable dt = new DataTable();
                            //daCheck.Fill(dt);
                            //sql.Close();
                            DataTable dt = db.HKLandACS.AccessGroup.QueryAccessGrp(Tower);
                            foreach (DataRow r in dt.Rows)
                            {
                                var matchingvalues = checkrepeatedList.Where(stringToCheck => stringToCheck.Contains(r["accessGrpID"].ToString()));
                                if (matchingvalues == null)
                                {
                                    //if (sql.State == ConnectionState.Closed)
                                    //    sql.Open();
                                    //SqlDataAdapter daCheck2 = new SqlDataAdapter("delete FROM dbo.AccessGrp where accessGrpID = '" + r["accessGrpID"].ToString() + "' AND Tower = '" + Tower + "'", sql);
                                    //sql.Close();
                                    db.HKLandACS.AccessGroup.DeleteAccessGrp(r["accessGrpID"].ToString(), Tower);
                                }
                            }
                            cardholderManagement.logger.Info("Getting Access Group Successfully!");
                            return true;
                        }
                        else
                        {
                            cardholderManagement.logger.Error("Failure in getting Access Group!" + response.ReasonPhrase);
                            return false;
                        }
                    }
                    catch (Exception e)
                    {
                        cardholderManagement.logger.Error(e, "Failure in getting Access Group!");
                        return false;
                    }
                }
                else
                {
                    cardholderManagement.logger.Error("Failure in getting Access Group: Connection Failure to GAL server!");
                    return false;
                }
            } while (pong.Status != IPStatus.Success && countforStop < 30);
        }
    }
}
