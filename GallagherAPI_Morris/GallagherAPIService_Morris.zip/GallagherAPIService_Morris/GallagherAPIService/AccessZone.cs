﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace GallagherAPIService
{
    public class AccessZone
    {
        static SqlConnection sql = connString.getConnString();
        static string Tower = ConfigurationManager.AppSettings["Tower"].ToString();
        public static async Task<bool> GetaccessZonechoice()
        {
            Ping ping;
            IPAddress address;
            PingReply pong;
            int countforStop = 0;
            do
            {
                countforStop = countforStop + 1;
                ping = new Ping();
                address = IPAddress.Parse(connString.GAL_Server_IP_address);
                pong = ping.Send(address);
                if (pong.Status == IPStatus.Success)
                {
                    try
                    {
                        //HttpResponseMessage response;
                        //using (Authentication._client())
                        //{
                        //    response = await Authentication._client().GetAsync("/api/access_zones?pos=0&previous=False&top=1000");
                        //}
                        Authentication._client();
                        List<string> checkrepeatedList = new List<string>();
                        //HttpResponseMessage response = await Authentication._client().GetAsync("/api/access_zones?pos=0&previous=False&top=10000");
                        HttpResponseMessage response = await Authentication._client().GetAsync("/api/access_zones?pos=0&previous=False&top=10000");
                        if (response.IsSuccessStatusCode)
                        {
                            string result = await response.Content.ReadAsStringAsync();
                            cardholderManagement.logger.Info("Get Access Zones:" + result);
                            var data = JsonConvert.DeserializeObject<AllAccessZoneConfig>(result);
                            foreach (resultsConfig2 r in data.results)
                            {
                                //if (sql.State == ConnectionState.Closed)
                                //    sql.Open();
                                //using (SqlCommand sqlcmd = new SqlCommand("addAccessZone", sql))
                                //{
                                //    sqlcmd.CommandType = CommandType.StoredProcedure;
                                //    sqlcmd.Parameters.AddWithValue("@Tower", Tower);
                                //    sqlcmd.Parameters.AddWithValue("@accessZoneName", r.name);
                                //    sqlcmd.Parameters.AddWithValue("@accessZoneID", r.id);
                                //    if (sql.State == ConnectionState.Closed)
                                //        sql.Open();
                                //    SqlCommand sqlcmd2 = new SqlCommand("SELECT count(*) FROM dbo.AccessZone where accessZoneID = '" + r.id + "' AND Tower = '" + Tower + "'", sql);
                                //    int count = (int)sqlcmd2.ExecuteScalar();
                                //    if (count > 0) { sql.Close(); }
                                //    else
                                //    {
                                //        sqlcmd.ExecuteNonQuery();
                                //    }
                                //}
                                //sql.Close();
                                if(db.HKLandACS.AccessZone.accessZoneIDExists(r.id,Tower) <= 0)
                                {
                                    db.HKLandACS.AccessZone.addAccessZone(Tower, r.name, r.id);
                                }
                                checkrepeatedList.Add(r.id);
                            }
                            //if (sql.State == ConnectionState.Closed)
                            //    sql.Open();
                            //SqlDataAdapter daCheck = new SqlDataAdapter("select accessZoneID FROM dbo.AccessZone where Tower = '" + Tower + "'", sql);
                            //DataTable dt = new DataTable();
                            //daCheck.Fill(dt);
                            //sql.Close();
                            DataTable dt = db.HKLandACS.AccessZone.QueryZone(Tower);
                            foreach (DataRow r in dt.Rows)
                            {
                                var matchingvalues = checkrepeatedList.Where(stringToCheck => stringToCheck.Contains(r["accessZoneID"].ToString()));
                                if (matchingvalues == null)
                                {
                                    //if (sql.State == ConnectionState.Closed)
                                    //    sql.Open();
                                    //SqlDataAdapter daCheck2 = new SqlDataAdapter("delete FROM dbo.AccessZone where accessZoneID = '" + r["accessZoneID"].ToString() + "' AND Tower = '" + Tower + "'", sql);
                                    //sql.Close();
                                    db.HKLandACS.AccessZone.DeleteZone(r["accessZoneID"].ToString(), Tower);
                                }
                            }
                            cardholderManagement.logger.Info("Getting Access Zone Successfully!");
                            return true;
                        }
                        else
                        {
                            cardholderManagement.logger.Error("Failure in getting Access Zone!" + response.ReasonPhrase);
                            return false;
                        }
                    }
                    catch (Exception e)
                    {
                        cardholderManagement.logger.Error(e, "Failure in getting Access Zone!");
                        return false;
                    }
                }
                else
                {
                    cardholderManagement.logger.Error("Failure in getting Access Zone: Connection Failure to GAL server!");
                    return false;
                }
            } while (pong.Status != IPStatus.Success && countforStop < 30);
        }
    }
}
