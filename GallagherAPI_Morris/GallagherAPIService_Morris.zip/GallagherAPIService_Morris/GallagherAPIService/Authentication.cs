﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace GallagherAPIService
{
    public class Authentication
    {
        static Authentication()
        {
            var handler = new HttpClientHandler();
            handler.ClientCertificateOptions = ClientCertificateOption.Manual;
            handler.ServerCertificateCustomValidationCallback =
                (httpRequestMessage, cert, cetChain, policyErrors) =>
                {
                    return true;
                };
            client = new HttpClient(handler);

            client.BaseAddress = new Uri("https://" + connString.GAL_Server_IP_address.Trim() + ":8904");
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Add($"Authorization", $" GGL-API-KEY " + API_KEY);
        }
        private static HttpClient client = null;
        static string API_KEY = ConfigurationManager.AppSettings["API_KEY"].ToString();
        public static HttpClient _client()
        {

            return client;
        }
    }
}
