﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace GallagherAPIService
{
    public class CardType
    {

        static SqlConnection sql = connString.getConnString();
        static string Tower = ConfigurationManager.AppSettings["Tower"].ToString();
        public static async Task<bool> GetcardType()
        {
            Ping ping;
            IPAddress address;
            PingReply pong;
            int countforStop = 0;
            do
            {
                countforStop++;
                ping = new Ping();
                address = IPAddress.Parse(connString.GAL_Server_IP_address);
                pong = ping.Send(address);
                if (pong.Status == IPStatus.Success)
                {
                    try
                    {
                        //HttpResponseMessage response;
                        //using (Authentication._client())
                        //{
                        //    response = await Authentication._client().GetAsync("/api/card_types/assign");
                        //}
                        Authentication._client();
                        List<string> checkrepeatedList = new List<string>();
                        HttpResponseMessage response = await Authentication._client().GetAsync("/api/card_types/assign");
                        if (response.IsSuccessStatusCode)
                        {
                            string result = await response.Content.ReadAsStringAsync();
                            cardholderManagement.logger.Info("Get Card Type:" + result);
                            var data = JsonConvert.DeserializeObject<AllAccessGrpConfig>(result);
                            //if (sql.State == ConnectionState.Closed)
                            //    sql.Open();
                            foreach (resultsConfig r in data.results)
                            {
                                //using (SqlCommand sqlcmd = new SqlCommand("allcardTypesGet", sql))
                                //{
                                //    sqlcmd.CommandType = CommandType.StoredProcedure;
                                //    sqlcmd.Parameters.AddWithValue("@System", "GAL");
                                //    sqlcmd.Parameters.AddWithValue("@Tower", Tower);
                                //    sqlcmd.Parameters.AddWithValue("@cardTypeName", r.name);
                                //    sqlcmd.Parameters.AddWithValue("@cardTypeID", r.id);
                                //    if (sql.State == ConnectionState.Closed)
                                //        sql.Open();
                                //    SqlCommand sqlcmd2 = new SqlCommand("SELECT count(*) FROM dbo.CardType where cardTypeID = '" + r.id + "' AND System = 'GAL' AND Tower = '" + Tower + "' ", sql);
                                //    int count = (int)sqlcmd2.ExecuteScalar();
                                //    if (count > 0) { sql.Close(); }
                                //    else
                                //    {
                                //        sqlcmd.ExecuteNonQuery();
                                //    }
                                if (db.HKLandACS.CardType.CardTypeIDExists(r.id, Tower) <= 0)
                                {
                                    db.HKLandACS.CardType.allcardTypesGet("GAL", Tower, r.name, r.id);
                                }
                                checkrepeatedList.Add(r.id);
                            }
                            //sql.Close();
                            //if (sql.State == ConnectionState.Closed)
                            //    sql.Open();
                            //SqlDataAdapter daCheck = new SqlDataAdapter("select cardTypeID FROM dbo.CardType where Tower = '" + Tower + "'", sql);
                            //DataTable dt = new DataTable();
                            //daCheck.Fill(dt);
                            //sql.Close();
                            DataTable dt = db.HKLandACS.CardType.QueryCardType(Tower);
                            foreach (DataRow r in dt.Rows)
                            {
                                var matchingvalues = checkrepeatedList.Where(stringToCheck => stringToCheck.Contains(r["cardTypeID"].ToString()));
                                if (matchingvalues == null)
                                {
                                    //if (sql.State == ConnectionState.Closed)
                                    //    sql.Open();
                                    //SqlDataAdapter daCheck2 = new SqlDataAdapter("delete FROM dbo.CardType where cardTypeID = '" + r["cardTypeID"].ToString() + "' AND Tower = '" + Tower + "'", sql);
                                    //sql.Close();
                                    db.HKLandACS.CardType.DeleteCardType(r["cardTypeID"].ToString(), Tower);
                                }
                            }
                            cardholderManagement.logger.Info("Getting Card Type Successfully!");
                            return true;
                        }
                        else
                        {
                            cardholderManagement.logger.Error("Failure in getting Card Type!" + response.ReasonPhrase);
                            return false;
                        }
                    }
                    catch (Exception e)
                    {
                        cardholderManagement.logger.Error(e, "Failure in getting Card Type!");
                        return false;
                    }
                }
                else
                {
                    cardholderManagement.logger.Error("Failure in getting Card Type: Connection Failure to GAL server!");
                    return false;
                }
            } while (pong.Status != IPStatus.Success && countforStop < 30);
        }
    }
}
