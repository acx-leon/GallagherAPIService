﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GallagherAPIService
{
    public class Company
    {
        static SqlConnection sql = connString.getConnString();
        static string Tower = ConfigurationManager.AppSettings["Tower"].ToString();
        public static bool GetcompanyNamechoice()
        {
            try
            {
                List<string> checkrepeatedList = new List<string>();
                //if (sql.State == ConnectionState.Closed)
                //    sql.Open();
                //SqlDataAdapter da = new SqlDataAdapter("SELECT Company_name FROM dbo.cardholder where Tower = '" + Tower + "' and System = 'GAL'", sql);
                //DataTable dt = new DataTable();
                //da.Fill(dt);
                DataTable dt = db.HKLandACS.Company.QueryCompany(Tower, "GAL");
                foreach (DataRow dr in dt.Rows)
                {
                    //if (sql.State == ConnectionState.Closed)
                    //    sql.Open();
                    //using (SqlCommand sqlcmd = new SqlCommand("addoldCompany", sql))
                    //{
                    //    sqlcmd.CommandType = CommandType.StoredProcedure;
                    //    sqlcmd.Parameters.AddWithValue("@System", "GAL");
                    //    sqlcmd.Parameters.AddWithValue("@Tower", Tower);
                    //    sqlcmd.Parameters.AddWithValue("@Company_name", dr["Company_name"].ToString());
                    //    SqlCommand sqlcmdget = new SqlCommand("SELECT count(*) FROM dbo.Company where Company_name = '" + dr["Company_name"].ToString() + "' AND System = 'GAL' AND Tower = '" + Tower + "'", sql);
                    //    int count2 = (int)sqlcmdget.ExecuteScalar();
                    //    if (count2 > 0) { sql.Close(); }
                    //    else
                    //    {
                    //        sqlcmd.ExecuteNonQuery();
                    //    }
                    if (db.HKLandACS.Company.CompanyNameExists(dr["Company_name"].ToString(), "GAL", Tower) <= 0)
                    {
                        db.HKLandACS.Company.AddOldCompany("GAL", Tower, dr["Company_name"].ToString());
                    }

                    checkrepeatedList.Add(dr["Company_name"].ToString());
                    cardholderManagement.logger.Info("Get Company:" + dr["Company_name"].ToString());
                }
                //sql.Close();
                //if (sql.State == ConnectionState.Closed)
                //    sql.Open();
                //SqlCommand sqlcmdCheck = new SqlCommand("Delete FROM dbo.Company where Company_name NOT IN ('" + string.Join("\',\'", checkrepeatedList) + "') AND System = 'GAL' AND Tower = '" + Tower + "' ", sql);
                //sqlcmdCheck.ExecuteNonQuery();
                //sql.Close();
                db.HKLandACS.Company.DeleteCompany(string.Join("\',\'", checkrepeatedList), "GAL", Tower);
                cardholderManagement.logger.Info("Getting All Company Successfully!");
                return true;
            }
            catch (Exception e)
            {
                cardholderManagement.logger.Error(e, "Fail to get Company in Gallagher");
                return false;
            }
        }
    }
}
