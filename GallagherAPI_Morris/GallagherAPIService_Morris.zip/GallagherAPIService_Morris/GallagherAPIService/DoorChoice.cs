﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace GallagherAPIService
{
    public class DoorChoice
    {
        static SqlConnection sql = connString.getConnString();
        static string Tower = ConfigurationManager.AppSettings["Tower"].ToString();
        public static async Task<bool> GetDoorchoice()
        {
            Ping ping;
            IPAddress address;
            PingReply pong;
            int countforStop = 0;
            do
            {
                countforStop = countforStop + 1;
                ping = new Ping();
                address = IPAddress.Parse(connString.GAL_Server_IP_address);
                pong = ping.Send(address);
                if (pong.Status == IPStatus.Success)
                {
                    try
                    {
                        //HttpResponseMessage response;
                        //using (Authentication._client())
                        //{
                        //    response = await Authentication._client().GetAsync("/api/doors?pos=0&previous=False&top=1000");
                        //}
                        Authentication._client();
                        List<string> checkrepeatedList = new List<string>();
                        //HttpResponseMessage response = await Authentication._client().GetAsync("/api/doors?pos=0&previous=False&top=10000");
                        HttpResponseMessage response = await Authentication._client().GetAsync("/api/doors?pos=0&previous=False&top=1000");
                        if (response.IsSuccessStatusCode)
                        {
                            string result = await response.Content.ReadAsStringAsync();
                            cardholderManagement.logger.Info("Get Doors:" + result);
                            var data = JsonConvert.DeserializeObject<AllAccessZoneConfig>(result);
                            foreach (resultsConfig2 r in data.results)
                            {
                                //if (sql.State == ConnectionState.Closed)
                                //    sql.Open();
                                //using (SqlCommand sqlcmd = new SqlCommand("addDoor", sql))
                                //{
                                //    sqlcmd.CommandType = CommandType.StoredProcedure;
                                //    sqlcmd.Parameters.AddWithValue("@Tower", Tower);
                                //    sqlcmd.Parameters.AddWithValue("@doorName", r.name);
                                //    sqlcmd.Parameters.AddWithValue("@doorID", r.id);
                                //    if (sql.State == ConnectionState.Closed)
                                //        sql.Open();
                                //    SqlCommand sqlcmd2 = new SqlCommand("SELECT count(*) FROM dbo.Door where doorID = '" + r.id + "' AND Tower = '" + Tower + "'", sql);
                                //    int count = (int)sqlcmd2.ExecuteScalar();
                                //    if (count > 0) { sql.Close(); }
                                //    else
                                //    {
                                //        sqlcmd.ExecuteNonQuery();
                                //    }
                                //}
                                //sql.Close();
                                if (db.HKLandACS.DoorChoice.DoorIDExists(r.id, Tower) <= 0)
                                {
                                    db.HKLandACS.DoorChoice.addDoor(Tower, r.name, r.id);
                                }
                                checkrepeatedList.Add(r.id);
                            }
                            //if (sql.State == ConnectionState.Closed)
                            //    sql.Open();
                            //SqlDataAdapter daCheck = new SqlDataAdapter("select doorID FROM dbo.Door where Tower = '" + Tower + "'", sql);
                            //DataTable dt = new DataTable();
                            //daCheck.Fill(dt);
                            //sql.Close();
                            DataTable dt = db.HKLandACS.DoorChoice.QueryDoor(Tower);
                            foreach (DataRow r in dt.Rows)
                            {
                                var matchingvalues = checkrepeatedList.Where(stringToCheck => stringToCheck.Contains(r["doorID"].ToString()));
                                if (matchingvalues == null)
                                {
                                    //if (sql.State == ConnectionState.Closed)
                                    //    sql.Open();
                                    //SqlDataAdapter daCheck2 = new SqlDataAdapter("delete FROM dbo.Door where doorID = '" + r["doorID"].ToString() + "' AND Tower = '" + Tower + "'", sql);
                                    //sql.Close();
                                    db.HKLandACS.DoorChoice.DeleteDoor(r["doorID"].ToString(), Tower);
                                }
                            }
                            cardholderManagement.logger.Info("Getting Door Successfully!");
                            return true;
                        }
                        else
                        {
                            cardholderManagement.logger.Error("Failure in getting Door!" + response.ReasonPhrase);
                            return false;
                        }
                    }
                    catch (Exception e)
                    {
                        cardholderManagement.logger.Error(e, "Failure in getting Door!");
                        return false;
                    }
                }
                else
                {
                    cardholderManagement.logger.Error("Failure in getting Door: Connection Failure to GAL server!");
                    return false;
                }
            } while (pong.Status != IPStatus.Success && countforStop < 30);
        }

    }
}
