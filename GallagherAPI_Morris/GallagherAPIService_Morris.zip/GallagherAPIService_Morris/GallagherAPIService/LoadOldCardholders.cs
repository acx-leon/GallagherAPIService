﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace GallagherAPIService
{
    public class LoadOldCardholders
    {
        static SqlConnection sql = connString.getConnString();
        static string Tower = ConfigurationManager.AppSettings["Tower"].ToString();
        public async static Task<bool> GetCardholder()
        {
            Ping ping;
            IPAddress address;
            PingReply pong;
            int countforStop = 0;
            do
            {
                countforStop++;
                ping = new Ping();
                address = IPAddress.Parse(connString.GAL_Server_IP_address);
                pong = ping.Send(address);
                if (pong.Status == IPStatus.Success)
                {
                    try
                    {
                        Authentication._client();
                        List<string> accessGrpList = new List<string>();
                        List<string> accessGrpIDList = new List<string>();
                        List<string> cardNumberList = new List<string>();
                        List<string> cardTypeNameList = new List<string>();
                        List<string> cardTypeIDList = new List<string>();
                        List<string> startDateList = new List<string>();
                        List<string> endDateList = new List<string>();
                        int skip = 0;
                        List<string> cardholderIDListInFirstGet = new List<string>();
                        string nexthrefInFirstGet = "";
                        do
                        {
                            int NumberOfCardholder = 100;
                            if (nexthrefInFirstGet != "")
                            {
                                skip = skip + NumberOfCardholder;
                            }
                            //var response;
                            //using (Authentication._client())
                            //{
                            //    response = await Authentication.client.GetStringAsync("/api/cardholders?skip=" + skip);
                            //}
                            var response = await Authentication._client().GetStringAsync("/api/cardholders?skip=" + skip);
                            cardholderManagement.logger.Info("Load all old cardholders: " + response);
                            var data = JsonConvert.DeserializeObject<AllAccessGrpConfig>(response);
                            foreach (resultsConfig r in data.results)
                            {
                                cardholderIDListInFirstGet.Add(r.id);
                            }
                            if (data.next != null)
                            {
                                nexthrefInFirstGet = data.next.href;
                            }
                            else
                            {
                                nexthrefInFirstGet = null;
                            }
                        } while (nexthrefInFirstGet != null);

                        using (SqlCommand sqlcmd = new SqlCommand("addoldCardholderGAL", sql))
                        {
                            sqlcmd.CommandType = CommandType.StoredProcedure;
                            sqlcmd.Parameters.AddWithValue("@Tower", Tower);
                            sqlcmd.Parameters.AddWithValue("@System", "GAL");
                            sqlcmd.Parameters.Add("@Company_name", SqlDbType.NVarChar, -1);
                            sqlcmd.Parameters.Add("@cardholderID", SqlDbType.NVarChar, -1);
                            sqlcmd.Parameters.Add("@startDate", SqlDbType.NVarChar, -1);
                            sqlcmd.Parameters.Add("@endDate", SqlDbType.NVarChar, -1);
                            sqlcmd.Parameters.Add("@firstName", SqlDbType.NVarChar, -1);
                            sqlcmd.Parameters.Add("@lastName", SqlDbType.NVarChar, -1);
                            sqlcmd.Parameters.Add("@cardNumber", SqlDbType.NVarChar, -1);
                            sqlcmd.Parameters.Add("@cardTypeName", SqlDbType.NVarChar, -1);
                            sqlcmd.Parameters.Add("@cardTypeID", SqlDbType.NVarChar, -1);
                            sqlcmd.Parameters.Add("@accessGrpName", SqlDbType.NVarChar, -1);
                            sqlcmd.Parameters.Add("@accessGrpID", SqlDbType.NVarChar, -1);

                            if (sql.State == ConnectionState.Closed)
                                sql.Open();

                            for (int ID = 0; ID < cardholderIDListInFirstGet.Count(); ID++)
                            {
                                //var responseID;
                                //using (Authentication._client())
                                //{
                                //    responseID = await Authentication.client.GetStringAsync("/api/cardholders/" + cardholderIDListInFirstGet[ID].ToString());
                                //}
                                var responseID = await Authentication._client().GetStringAsync("/api/cardholders/" + cardholderIDListInFirstGet[ID].ToString());

                                var dataID = JsonConvert.DeserializeObject<createCardholderConfig>(responseID);
                                sqlcmd.CommandType = CommandType.StoredProcedure;
                                sqlcmd.Parameters["@cardholderID"].Value = dataID.id.ToString();

                                if (dataID.firstName != null)
                                {
                                    sqlcmd.Parameters["@Company_name"].Value = dataID.firstName;
                                    sqlcmd.Parameters["@firstName"].Value = dataID.firstName;
                                }

                                if (dataID.lastName != null)
                                {
                                    sqlcmd.Parameters["@lastName"].Value = dataID.lastName;
                                }
                                else
                                {
                                    sqlcmd.Parameters["@lastName"].Value = "NULL";
                                }

                                int i = 0;
                                int j = 0;
                                    if (dataID.accessGroups != null)
                                    {
                                        foreach (accessGrpsConfig a in dataID.accessGroups)
                                        {
                                            if (dataID.accessGroups.Count() >= 1)
                                            {
                                            i++;
                                            accessGrpList.Add(a.accessGroup.name);

                                            var href = a.accessGroup.href.Split('/');
                                            var id = string.Empty;
                                            if (href != null && href.Count() > 0)
                                                id = href[5].Trim();
                                            accessGrpIDList.Add(id);

                                            if (i == dataID.accessGroups.Count())
                                            {
                                                string combindedString = string.Join(",", accessGrpList);

                                                sqlcmd.Parameters["@accessGrpName"].Value = combindedString;
                                                accessGrpList = new List<string>();

                                                string combindedStringID = string.Join(",", accessGrpIDList);

                                                sqlcmd.Parameters["@accessGrpID"].Value = combindedStringID;
                                                accessGrpIDList = new List<string>();
                                            }
                                        }
                                        else
                                        {
                                            sqlcmd.Parameters["@accessGrpName"].Value = a.accessGroup.name;
                                            var href = a.accessGroup.href.Split('/');
                                            var id = string.Empty;
                                            if (href != null && href.Count() > 0)
                                                id = href[5].Trim();

                                            sqlcmd.Parameters["@accessGrpID"].Value = id;
                                        }
                                    }
                                }

                                if (dataID.cards != null)
                                {
                                    foreach (cardsConfig c in dataID.cards)
                                    {
                                        if (dataID.cards.Count() > 1)
                                        {
                                            Console.WriteLine("dataID.cards.Count() > 1" + dataID.cards.Count().ToString());
                                            j++;
                                            cardNumberList.Add(c.number);
                                            cardTypeNameList.Add(c.type.name);
                                            cardTypeIDList.Add(c.type.href.Split('/')[5]);
                                            if (c.from != null)
                                            {
                                                startDateList.Add(c.from);
                                                endDateList.Add(c.until);
                                            }

                                            if (j == dataID.cards.Count())
                                            {
                                                sqlcmd.Parameters["@cardNumber"].Value = string.Join(",", cardNumberList);
                                                sqlcmd.Parameters["@cardTypeName"].Value = string.Join(",", cardTypeNameList);
                                                sqlcmd.Parameters["@cardTypeID"].Value = string.Join(",", cardTypeIDList);
                                                if (c.from != null)
                                                {
                                                    sqlcmd.Parameters["@startDate"].Value = string.Join(",", startDateList);
                                                    sqlcmd.Parameters["@endDate"].Value = string.Join(",", endDateList);
                                                }
                                                cardNumberList = new List<string>();
                                                cardTypeNameList = new List<string>();
                                                cardTypeIDList = new List<string>();
                                                startDateList = new List<string>();
                                                endDateList = new List<string>();
                                            }
                                        }
                                        else if (dataID.cards.Count() == 1)
                                        {
                                            Console.WriteLine("dataID.cards.Count() == 1" + dataID.cards.Count().ToString());
                                            sqlcmd.Parameters["@cardNumber"].Value = c.number;
                                            sqlcmd.Parameters["@cardTypeName"].Value = c.type.name;
                                            sqlcmd.Parameters["@cardTypeID"].Value = c.type.href.Split('/')[5];
                                            if (c.from != null)
                                            {
                                                sqlcmd.Parameters["@startDate"].Value = c.from;
                                                sqlcmd.Parameters["@endDate"].Value = c.until;
                                            }
                                            else
                                            {
                                                sqlcmd.Parameters["@startDate"].Value = "NULL";
                                                sqlcmd.Parameters["@endDate"].Value = "NULL";
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    sqlcmd.Parameters["@cardNumber"].Value = "NULL";
                                    sqlcmd.Parameters["@cardTypeName"].Value = "NULL";
                                    sqlcmd.Parameters["@cardTypeID"].Value = "NULL";
                                    sqlcmd.Parameters["@startDate"].Value = "NULL";
                                    sqlcmd.Parameters["@endDate"].Value = "NULL";
                                }

                                if (sql.State == ConnectionState.Closed)
                                    sql.Open();
                                SqlCommand sqlcmd2 = new SqlCommand("SELECT count(*) FROM dbo.cardholder where cardholderID = '" + dataID.id.ToString() + "' AND System = 'GAL' AND Tower = '" + Tower + "'", sql);
                                int count = (int)sqlcmd2.ExecuteScalar();
                                if (count > 0) { sql.Close(); }
                                else
                                {
                                    sqlcmd.ExecuteNonQuery();
                                }

                            }
                            sql.Close();
                        }
                        //if (sql.State == ConnectionState.Closed)
                        //    sql.Open();
                        //SqlDataAdapter daCheck = new SqlDataAdapter("select cardholderID FROM dbo.cardholder where Tower = '" + Tower + "' AND [System] = 'GAL'", sql);
                        //DataTable dt = new DataTable();
                        //daCheck.Fill(dt);
                        //sql.Close();
                        DataTable dt = db.HKLandACS.LoadOldCardholders.QueryOldCardholders(Tower);
                        foreach (DataRow r in dt.Rows)
                        {
                            var matchingvalues = cardholderIDListInFirstGet.Where(stringToCheck => stringToCheck.Contains(r["cardholderID"].ToString()));
                            if (matchingvalues == null)
                            {
                                //if (sql.State == ConnectionState.Closed)
                                //    sql.Open();
                                //SqlDataAdapter daCheck2 = new SqlDataAdapter("delete FROM dbo.cardholder where cardholderID = '" + r["cardholderID"].ToString() + "' AND Tower = '" + Tower + "' AND [System] = 'GAL'", sql);
                                //sql.Close();
                                db.HKLandACS.LoadOldCardholders.DeleteOldCardholders(r["cardholderID"].ToString(), Tower);
                            }
                        }
                        cardholderManagement.logger.Info("All Cardholders are get successfully in Gallagher.");
                        return true;
                    }
                    catch (Exception e)
                    {
                        cardholderManagement.logger.Error(e, "Failure in getting all cardholders!");
                        return false;
                    }
                }
                else
                {
                    cardholderManagement.logger.Error("Failure in getting all cardholders: Connection Failure to GAL server!");
                    return false;
                }
            } while (pong.Status != IPStatus.Success && countforStop < 30);
        }
    }
}
