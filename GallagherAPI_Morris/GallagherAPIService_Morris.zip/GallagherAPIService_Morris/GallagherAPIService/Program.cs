﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Topshelf;

namespace GallagherAPIService
{
    class Program
    {
        static void Main(string[] args)
        {
            var exitCode = HostFactory.Run(x =>
            {
                x.Service<cardholderManagement>(s =>
                {
                    s.ConstructUsing(cardholderManagement => new cardholderManagement());
                    s.WhenStarted(cardholderManagement => cardholderManagement.Start());
                    s.WhenStopped(cardholderManagement => cardholderManagement.Stop());
                });

                x.RunAsLocalSystem();
                x.SetServiceName("ACX_GallagherAPIService");
                x.SetDisplayName("ACXGallagher API Service");
                x.SetDescription("Cardholder Management in Gallagher");
            });

            int exitCodeValue = (int)Convert.ChangeType(exitCode, exitCode.GetTypeCode());
            Environment.ExitCode = exitCodeValue;
        }
    }
}
