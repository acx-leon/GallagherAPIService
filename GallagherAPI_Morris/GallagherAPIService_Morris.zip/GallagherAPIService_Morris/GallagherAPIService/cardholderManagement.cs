﻿using Newtonsoft.Json;
using NLog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using TableDependency.SqlClient;
using TableDependency.SqlClient.Base.Enums;
using TableDependency.SqlClient.Base.EventArgs;

namespace GallagherAPIService
{
    public class cardholderManagement
    {
        public static SqlTableDependency<update_GAL> update_GAL_dependency;
        public static string _msg = "";
        public static DataSet ds1 = new DataSet();
        static SqlDataAdapter da = new SqlDataAdapter();
        public static SqlConnection sql = connString.getConnString();
        private static Timer _timer;
        private static Timer _timer2;
        private static Timer _timer3;
        public static Ping ping;
        public static IPAddress address;
        public static PingReply pong;
        public static Logger logger = LogManager.GetLogger("fileLogger");

        public cardholderManagement()
        {
            //_timer = new Timer(1000 * 1 * 60) { AutoReset = true };
            _timer = new Timer(1000 * 1 * 60) { AutoReset = true };
            _timer.Elapsed += TimerElapsed;
            _timer2 = new Timer(1000) { AutoReset = true };
            _timer2.Elapsed += TimerElapsed2;
            _timer3 = new Timer(1000 * 60 * 60) { AutoReset = true };
            _timer3.Elapsed += TimerElapsed3;
        }

        private async void TimerElapsed3(object sender, ElapsedEventArgs e)
        {
            await LoadOldCardholders.GetCardholder();
        }

        //public static void DailyTime()
        //{
        //    try
        //    {
        //        var DailyTime = "01:00:00";
        //        var timeParts = DailyTime.Split(new char[1] { ':' });

        //        var dateNow = DateTime.Now;
        //        var date = new DateTime(dateNow.Year, dateNow.Month, dateNow.Day,
        //                   int.Parse(timeParts[0]), int.Parse(timeParts[1]), int.Parse(timeParts[2]));
        //        TimeSpan ts;
        //        if (date > dateNow)
        //            ts = date - dateNow;
        //        else
        //        {
        //            date = date.AddDays(1);
        //            ts = date - dateNow;
        //        }
        //        Task.Delay(ts).ContinueWith((x) => DeleteAt0100());
        //        cardholderManagement.logger.Info("Delete those records in dbo.Update_GAL at 01:00:00:" + "\r\n" + "Datetime now: " + DateTime.Now + "\r\n" + "TimeLeft: " + ts);
        //    }
        //    catch (Exception err)
        //    {
        //        logger.Error(err, "Cannot start timer to delete those records in dbo.Update_GAL at 01:00:00");
        //    }
        //}

        //public static void DeleteAt0100()
        //{
        //    try
        //    {
        //        if (sql.State == ConnectionState.Closed)
        //            sql.Open();
        //        SqlCommand daDelete = new SqlCommand("delete from dbo.update_GAL", sql);
        //        daDelete.ExecuteNonQuery();
        //        sql.Close();
        //        cardholderManagement.logger.Info("Delete those records in dbo.Update_GAL at 01:00:00 successfully!");
        //    }
        //    catch (Exception err)
        //    {
        //        logger.Error(err, "Cannot delete those records in dbo.Update_GAL at 01:00:00");
        //    }
        //}
        private async void TimerElapsed(object sender, ElapsedEventArgs e)
        {
            if (await AccessGroup.GetaccessGrpchoice() == true)
            {
                if (await CardType.GetcardType() == true)
                {
                    await eventViewer.getEvent();
                }
            }
            //Company.GetcompanyNamechoice();
        }

        public static void TimerElapsed2(object sender, ElapsedEventArgs e)
        {
            update_GAL_Changed();
        }

        public async static void update_GAL_Changed(/*object sender, RecordChangedEventArgs<update_GAL> e*/)
        {
            //Console.WriteLine("Activated");
            try
            {
                //    var changedEntity = e.Entity;
                //    switch (e.ChangeType)
                //    {
                //        case ChangeType.Insert:
                //            Console.WriteLine("Inserted");
                //            {
                //                update_GAL_dependency.Stop();
                _timer2.Enabled = false;
                if (sql.State == ConnectionState.Closed)
                    sql.Open();
                da = new SqlDataAdapter("select * from dbo.update_GAL where Success_time IS NULL AND Fail_time IS NULL", sql);
                ds1.Clear();
                da.Fill(ds1, "update_GAL");
                sql.Close();
                List<string> AccessGrpName = new List<string>();
                List<string> AccessGrpID = new List<string>();
                string lastName = "";
                string firstName = "";
                if (ds1.Tables["update_GAL"].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds1.Tables["update_GAL"].Rows)
                    {
                        if (dr["firstName"].ToString() == "")
                        {
                            firstName = dr["company_name"].ToString();
                        }
                        else
                        {
                            firstName = dr["firstName"].ToString();
                        }

                        if (dr["lastName"].ToString() == "")
                        {
                            lastName = dr["company_name"].ToString();
                        }
                        else
                        {
                            lastName = dr["lastName"].ToString();
                        }

                        if (dr["accessGrpName"].ToString().Contains(","))
                        {
                            for (int n = 0; n < dr["accessGrpName"].ToString().Split(',').Length; n++)
                            {
                                AccessGrpName.Add(dr["accessGrpName"].ToString().Split(',')[n]);
                                AccessGrpID.Add(dr["accessGrpID"].ToString().Split(',')[n]);
                            }
                        }
                        else if (dr["accessGrpName"].ToString() == "NULL")
                        {
                            AccessGrpName = null;
                            AccessGrpID = null;
                        }
                        else
                        {
                            AccessGrpName.Add(dr["accessGrpName"].ToString());
                            AccessGrpID.Add(dr["accessGrpID"].ToString());
                        }
                        if (dr["Action"].ToString() == "ADD")
                        {
                            if (await AddCardholder(inputCardholderInfo(firstName, lastName, AccessGrpName, AccessGrpID, dr["cardNumber"].ToString(), dr["cardTypeID"].ToString(), dr["startDate"].ToString(), dr["endDate"].ToString()), dr["lastName"].ToString(), dr["cardNumber"].ToString(), dr["cardTypeID"].ToString(), dr["cardTypeName"].ToString(), dr["Add_time"].ToString(), dr["Tower"].ToString()) == true)
                            {
                                logger.Info(_msg);
                            }
                            else
                            {
                                logger.Info(_msg);
                            }
                        }
                        else if (dr["Action"].ToString() == "DELETE")
                        {
                            if (DelCardholder(dr["cardholderID"].ToString(), dr["lastName"].ToString(), dr["Add_time"].ToString(), dr["Tower"].ToString()) == true)
                            {
                                logger.Info(_msg);
                            }
                            else
                            {
                                logger.Info(_msg);
                            }
                        }
                        else if (dr["Action"].ToString() == "DC")
                        {
                            List<string> cardholderList = new List<string>();
                            for (int i = 0; i < dr["cardholderID"].ToString().Split(',').Length; i++)
                            {
                                cardholderList.Add(dr["cardholderID"].ToString().Split(',')[i]);
                            }
                            if (delCompany(dr["Company_name"].ToString(), dr["Add_time"].ToString(), dr["Tower"].ToString(), cardholderList) == true)
                            {
                                logger.Info(_msg);
                            }
                            else
                            {
                                logger.Info(_msg);
                            }
                        }
                        else if (dr["Action"].ToString() == "EDIT")
                        {
                            List<string> accessGrpAdd = new List<string>();
                            for (int i = 0; i < dr["accessGrpID"].ToString().Split(',').Length; i++)
                            {
                                accessGrpAdd.Add(dr["accessGrpID"].ToString().Split(',')[i]);
                            }
                            var responseID = await Authentication._client().GetStringAsync("/api/cardholders/" + dr["cardholderID"].ToString());
                            var dataID = JsonConvert.DeserializeObject<createCardholderConfig>(responseID);
                            List<string> accessGrpAddReal = new List<string>();
                            List<string> accessGrpAddKeep = new List<string>();
                            List<string> accessGrpRemove = new List<string>();
                            List<string> accessGrpRemoveHref = new List<string>();
                            
                            if (dataID.accessGroups != null)
                            {
                                foreach (accessGrpsConfig a in dataID.accessGroups)
                                {
                                    if (dataID.accessGroups.Count() >= 1)
                                    {
                                        accessGrpRemove.Add(a.accessGroup.href.Split('/')[5] + "," + a.href);
                                    }
                                }
                            }
                            string card_href = "";
                            string issueLevel = "";
                            if (dataID.cards != null) {
                                foreach (cardsConfig c in dataID.cards)
                                {
                                    card_href = c.href;
                                    issueLevel = c.issueLv;
                                }
                            }

                            for (int i = 0; i < accessGrpRemove.Count; i++)
                            {
                                if (accessGrpAdd.Contains(accessGrpRemove[i].Split(',')[0]) == false)
                                {
                                    accessGrpRemoveHref.Add(accessGrpRemove[i].Split(',')[1]);
                                }
                                else
                                {
                                    accessGrpAddKeep.Add(accessGrpRemove[i].Split(',')[0]);
                                }
                            }

                            accessGrpAddReal = accessGrpAdd.Except(accessGrpAddKeep).ToList();

                            if (await EditCardholder(inputEditCardholderInfo(dr["cardholderID"].ToString(), dr["firstName"].ToString(), dr["lastName"].ToString(), card_href, Int16.Parse(issueLevel), accessGrpAddReal, accessGrpRemoveHref, dr["endDate"].ToString()), dr["cardholderID"].ToString(), dr["firstName"].ToString(), dr["lastName"].ToString(), dr["accessGrpName"].ToString(), dr["accessGrpID"].ToString(), dr["company_name"].ToString(), dr["endDate"].ToString(), dr["Gender"].ToString(), dr["VIP"].ToString(), dr["Add_time"].ToString(), dr["tower"].ToString()) == true)
                            {
                                logger.Info("Cardholder - (" + dr["cardNumber"].ToString() + "," + dr["cardTypeName"].ToString() + ") is edited!");
                            }
                            else
                            {
                                logger.Info(_msg);
                            }
                        }
                        AccessGrpName = new List<string>();
                        AccessGrpID = new List<string>();
                    }
                    //        if (sql.State == ConnectionState.Closed)
                    //            sql.Open();
                    //        da = new SqlDataAdapter("select * from dbo.update_GAL where Success_time IS NULL AND Fail_time IS NULL", sql);
                    //        ds1.Clear();
                    //        da.Fill(ds1, "update_GAL");                               
                    //    } while (ds1.Tables["update_GAL"].Rows.Count > 0);
                    //    sql.Close();
                    //    update_GAL_dependency = new SqlTableDependency<update_GAL>("server = 8.210.202.130; Database=HKL;uid=sa;pwd=AcxSql@pAssW0rd325");
                    //    update_GAL_dependency.OnChanged += update_GAL_dependency_Changed;
                    //    update_GAL_dependency.Start();
                    //}
                    sql.Close();
                }
                _timer2 = new Timer(1000) { AutoReset = true };
                _timer2.Elapsed += TimerElapsed2;
                _timer2.Enabled = true;
            }
            catch (Exception err)
            {
                logger.Error(err, "Failure in cardholder management via Gallagher API");
            }
        }

        //public static bool stop_update_GAL_dependency()
        //{
        //    try
        //    {
        //        if (update_GAL_dependency != null)
        //        {
        //            update_GAL_dependency.Stop();
        //            return true;
        //        }
        //        return false;
        //    }
        //    catch (Exception err)
        //    {
        //        Console.WriteLine(err.Message.ToString());
        //        return false;
        //    }
        //}

        public static createCardholderConfigforadd inputCardholderInfo(string firstName, string lastName, List<string> accessGrpNameList, List<string> accessGrpIDList, string cardNo, string cardTypeID, string startDate, string endDate)
        {
            try
            {
                if (firstName.Length > 40 || firstName.Length == 40)
                {
                    firstName = firstName.Substring(0, 40);
                }
                if (lastName.Length > 40 || lastName.Length == 40)
                {
                    lastName = lastName.Substring(0, 40);
                }
                List<accessGrpsConfigforadd> accessGrp = new List<accessGrpsConfigforadd>();
                if (accessGrpNameList.Count > 1)
                {
                    for (int i = 0; i < accessGrpNameList.Count; i++)
                    {
                        accessGrp.Add(new accessGrpsConfigforadd { accessGroup = new accessGrpConfig() { name = accessGrpNameList[i], href = "https://192.168.10.210:8904/api/access_groups/" + accessGrpIDList[i] }, status = new accessGrpStatus() { value = "Active", type = "active" } });
                    }
                }
                else
                {
                    accessGrp.Add(new accessGrpsConfigforadd { accessGroup = new accessGrpConfig() { name = accessGrpNameList[0], href = "https://192.168.10.210:8904/api/access_groups/" + accessGrpIDList[0] }, status = new accessGrpStatus() { value = "Active", type = "active" } });
                }

                createCardholderConfigforadd cardholder = new createCardholderConfigforadd()
                {
                    firstName = firstName,
                    lastName = lastName,
                    authorised = true,
                    division = new cardholderDivisionConfig()
                    {
                        href = "https://192.168.10.210:8904/api/divisions/2"
                    },
                    cards = new List<cardsConfigforadd>()
                {
                    new cardsConfigforadd { type = new cardTypeConfigforadd() { href = "https://192.168.10.210:8904/api/card_types/" + cardTypeID}, number = cardNo, from = startDate,until = endDate}
                },
                    accessGroups = accessGrp,

                    notifications = new notificationConfig()
                    {
                        enabled = false
                    }
                };
                return cardholder;
            }
            catch (Exception err)
            {
                logger.Error(err, "Failure in creating cardholder json string");
                return null;
            }
        }

        public static EditCardholder inputEditCardholderInfo(string cardholderID, string firstName, string lastName, string cardHref, int cardIssueLv, List<string> accessGrpADD, List<string> accessGrpRemoveHref, string endDate)
        {
            try
            {
                if (firstName.Length > 40 || firstName.Length == 40)
                {
                    firstName = firstName.Substring(0, 40);
                }
                if (lastName.Length > 40 || lastName.Length == 40)
                {
                    lastName = lastName.Substring(0, 40);
                }
                IList<Add> accessGrpAdd = new List<Add>();
                if (accessGrpADD.Count > 0)
                {
                    for (int i = 0; i < accessGrpADD.Count; i++)
                    {
                        accessGrpAdd.Add(new Add { accessGroup = new AccessGroupEdit { href = "https://10.160.17.201:8904/api/access_groups/" + accessGrpADD[i] } } );
                    }
                }

                IList<Remove> accessGrpRemove = new List<Remove>();
                if (accessGrpRemoveHref.Count > 0)
                {
                    for (int i = 0; i < accessGrpRemoveHref.Count; i++)
                    {
                        accessGrpRemove.Add( new Remove { href = accessGrpRemoveHref[i] } );
                    }
                }
                else
                {
                    accessGrpRemove = new List<Remove>();
                }

                EditCardholder cardholder = new EditCardholder()
                {
                    firstName = firstName,
                    lastName = lastName,
                    authorised = true,
                    cards = new Cards()
                    {
                        update = new List<Update>() { new Update { href = cardHref, issueLevel = cardIssueLv, until = endDate } }
                    },
                    accessGroups = new AccessGroups()
                    {
                        add = accessGrpAdd,
                        remove = accessGrpRemove
                    }
                };
                return cardholder;
            }
            catch (Exception err)
            {
                logger.Error(err, "Failure in editing cardholder json string");
                return null;
            }
        }

        public async static Task<bool> AddCardholder(createCardholderConfigforadd cardholder, string lastName, string cardNumber, string cardTypeID, string cardTypeName, string addTime, string tower)
        {
            Ping ping;
            IPAddress address;
            PingReply pong;
            int countforStop = 0;
            do
            {
                countforStop = countforStop + 1;
                ping = new Ping();
                address = IPAddress.Parse(connString.GAL_Server_IP_address);
                pong = ping.Send(address);
                if (pong.Status == IPStatus.Success)
                {
                    try
                    {
                        Authentication._client();
                        string card = JsonConvert.SerializeObject(cardholder);
                        cardholderManagement.logger.Info("Add card (input): " + card);
                        var content = new StringContent(card, Encoding.UTF8, "application/json");
                        content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                        HttpResponseMessage response = await Authentication._client().PostAsync("/api/cardholders", content);

                        if (response.IsSuccessStatusCode)
                        {
                            string Location = response.Headers.GetValues("Location").FirstOrDefault();
                            var newhref = Location.Split('/');
                            var cardHolderID = string.Empty;
                            if (newhref != null && newhref.Count() > 0)
                            {
                                cardHolderID = newhref[5].Trim();
                            }
                            if (sql.State == ConnectionState.Closed)
                                sql.Open();
                            SqlCommand sqlcmdrecent = new SqlCommand("UPDATE dbo.addedCard SET GALcardholderID = '" + cardHolderID + "', Success_time = @DatetimeNow WHERE GALcardNumber = '" + cardNumber + "' and GALcardTypeName = '" + cardTypeName + "' and Add_time = '" + addTime + "'", sql);
                            sqlcmdrecent.Parameters.AddWithValue("@DatetimeNow ", DateTime.Now);
                            sqlcmdrecent.ExecuteNonQuery();
                            SqlCommand sqlcmdx90 = new SqlCommand("UPDATE dbo.cardholder SET cardholderID = '" + cardHolderID + "' WHERE cardNumber = '" + cardNumber + "' and cardTypeID = '" + cardTypeID + "' and System = 'GAL' and tower = '" + tower + "'", sql);
                            sqlcmdx90.ExecuteNonQuery();
                            SqlCommand sqlcmdlog = new SqlCommand("UPDATE dbo.log_GAL SET cardholderID = '" + cardHolderID + "', Success_time = @DatetimeNow WHERE ( cardNumber = '" + cardNumber + "' and cardTypeID = '" + cardTypeID + "' and [Action] = 'ADD' and Add_time = '" + addTime + "') OR (  cardNumber = '" + cardNumber + "' and cardTypeID = '" + cardTypeID + "' and [Action] = 'Eadd' and Add_time = '" + addTime + "')", sql);
                            sqlcmdlog.Parameters.AddWithValue("@DatetimeNow ", DateTime.Now);
                            sqlcmdlog.ExecuteNonQuery();
                            SqlCommand sqlcmdupdate = new SqlCommand("UPDATE dbo.update_GAL SET cardholderID = '" + cardHolderID + "', Success_time = @DatetimeNow WHERE ( cardNumber = '" + cardNumber + "' and cardTypeID = '" + cardTypeID + "' and [Action] = 'ADD' and Add_time = '" + addTime + "') OR (  cardNumber = '" + cardNumber + "' and cardTypeID = '" + cardTypeID + "' and [Action] = 'Eadd' and Add_time = '" + addTime + "')", sql);
                            sqlcmdupdate.Parameters.AddWithValue("@DatetimeNow ", DateTime.Now);
                            sqlcmdupdate.ExecuteNonQuery();
                            sql.Close();
                            _msg = "Cardholder - (" + cardHolderID + ") is added via Gallagher API. Status code:" + "\r\n" + response.ReasonPhrase;
                            return true;
                        }
                        else
                        {
                            if (sql.State == ConnectionState.Closed)
                                sql.Open();
                            SqlCommand sqlcmdrecentAdded = new SqlCommand("UPDATE dbo.addedCard SET GALFail_time = @DatetimeNow WHERE GALcardNumber = '" + cardNumber + "' and GALcardTypeName = '" + cardTypeName + "' and Add_time = '" + addTime + "'", sql);
                            sqlcmdrecentAdded.Parameters.AddWithValue("@DatetimeNow ", DateTime.Now);
                            sqlcmdrecentAdded.ExecuteNonQuery();
                            SqlCommand sqlcmdx90 = new SqlCommand("delete from dbo.cardholder WHERE cardNumber = '" + cardNumber + "' and cardTypeID = '" + cardTypeID + "' and System = 'GAL' and cardholderID is null and Tower = '" + tower + "'", sql);
                            sqlcmdx90.ExecuteNonQuery();
                            SqlCommand sqlcmdlog = new SqlCommand("UPDATE dbo.log_GAL SET Fail_time = @DatetimeNow WHERE ( cardNumber = '" + cardNumber + "' and cardTypeID = '" + cardTypeID + "' and [Action] = 'ADD' and Add_time = '" + addTime + "' ) OR (  cardNumber = '" + cardNumber + "' and cardTypeID = '" + cardTypeID + "' and [Action] = 'Eadd' and Add_time = '" + addTime + "')", sql);
                            sqlcmdlog.Parameters.AddWithValue("@DatetimeNow ", DateTime.Now);
                            sqlcmdlog.ExecuteNonQuery();
                            SqlCommand sqlcmdupdate = new SqlCommand("UPDATE dbo.update_GAL SET Fail_time = @DatetimeNow WHERE ( cardNumber = '" + cardNumber + "' and cardTypeID = '" + cardTypeID + "' and [Action] = 'ADD' and Add_time = '" + addTime + "' ) OR (  cardNumber = '" + cardNumber + "' and cardTypeID = '" + cardTypeID + "' and [Action] = 'Eadd' and Add_time = '" + addTime + "')", sql);
                            sqlcmdupdate.Parameters.AddWithValue("@DatetimeNow ", DateTime.Now);
                            sqlcmdupdate.ExecuteNonQuery();
                            sql.Close();
                            _msg = "Failed to add cardholder  - (" + cardNumber + "," + cardTypeName + "). Status code:" + "\r\n" + response.ReasonPhrase;
                            return false;
                        }
                    }
                    catch (Exception err)
                    {
                        logger.Error(err, "Failure in adding cardholder towards GAL API");
                        return false;
                    }
                }
                else
                {
                    logger.Error("Failure in adding cardholder towards GAL API: Connection Failure to GAL server!");
                    return false;
                }
            } while (pong.Status != IPStatus.Success && countforStop < 30);
        }

        public static bool DelCardholder(string cardholderID, string lastName, string addTime, string tower)
        {
            Ping ping;
            IPAddress address;
            PingReply pong;
            int countforStop = 0;
            do
            {
                countforStop = countforStop + 1;
                ping = new Ping();
                address = IPAddress.Parse(connString.GAL_Server_IP_address);
                pong = ping.Send(address);
                if (pong.Status == IPStatus.Success)
                {
                    try
                    {
                        Authentication._client();
                        var response = Authentication._client().DeleteAsync("api/cardholders/" + cardholderID).Result;
                        if (response.IsSuccessStatusCode)
                        {
                            if (sql.State == ConnectionState.Closed)
                            {
                                sql.Open();
                            }
                            SqlCommand del = new SqlCommand("DELETE FROM dbo.cardholder WHERE cardholderID = '" + cardholderID + "' and System = 'GAL' and Tower = '" + tower + "'", sql);
                            del.ExecuteNonQuery();
                            SqlCommand del1 = new SqlCommand("DELETE FROM dbo.addedCard WHERE GALcardholderID = '" + cardholderID + "' and tower = '" + tower + "'", sql);
                            del1.ExecuteNonQuery();
                            SqlCommand del_log = new SqlCommand("UPDATE dbo.log_GAL SET Success_time = @DatetimeNow WHERE ( cardholderID = '" + cardholderID + "' and [Action] = 'Edelete' and Add_time = '" + addTime + "' ) OR ( cardholderID = '" + cardholderID + "' and [Action] = 'DELETE' and Add_time = '" + addTime + "' ) ", sql);
                            del_log.Parameters.AddWithValue("@DatetimeNow ", DateTime.Now);
                            del_log.ExecuteNonQuery();
                            SqlCommand del_update = new SqlCommand("UPDATE dbo.update_GAL SET Success_time = @DatetimeNow WHERE ( cardholderID = '" + cardholderID + "' and [Action] = 'Edelete' and Add_time = '" + addTime + "') OR ( cardholderID = '" + cardholderID + "' and [Action] = 'DELETE' and Add_time = '" + addTime + "' ) ", sql);
                            del_update.Parameters.AddWithValue("@DatetimeNow ", DateTime.Now);
                            del_update.ExecuteNonQuery();
                            sql.Close();
                            _msg = "Delete cardholder - " + cardholderID + " successfully. Status code:" + response.StatusCode;
                            return true;
                        }
                        else
                        {
                            if (sql.State == ConnectionState.Closed)
                            {
                                sql.Open();
                            }
                            SqlCommand del_log = new SqlCommand("UPDATE dbo.log_GAL SET Fail_time = @DatetimeNow WHERE ( cardholderID = '" + cardholderID + "' and [Action] = 'Edelete' and Add_time = '" + addTime + "' ) OR ( cardholderID = '" + cardholderID + "' and [Action] = 'DELETE' and Add_time = '" + addTime + "' ) ", sql);
                            del_log.Parameters.AddWithValue("@DatetimeNow ", DateTime.Now);
                            del_log.ExecuteNonQuery();
                            SqlCommand del_update = new SqlCommand("UPDATE dbo.update_GAL SET Fail_time = @DatetimeNow WHERE ( cardholderID = '" + cardholderID + "' and [Action] = 'Edelete' and Add_time = '" + addTime + "' ) OR ( cardholderID = '" + cardholderID + "' and [Action] = 'DELETE' and Add_time = '" + addTime + "' ) ", sql);
                            del_update.Parameters.AddWithValue("@DatetimeNow ", DateTime.Now);
                            del_update.ExecuteNonQuery();
                            sql.Close();
                            _msg = "Failed to delete cardholder - '" + cardholderID + "'. Status code:" + response.StatusCode;
                            return false;
                        }
                    }
                    catch (Exception err)
                    {
                        logger.Error(err, "Failure in deleting cardholder towards GAL API");
                        return false;
                    }
                }
                else
                {
                    logger.Error("Failure in deleting cardholder towards GAL API: Connection Failure to GAL server!");
                    return false;
                }
            } while (pong.Status != IPStatus.Success && countforStop < 30);
        }

        public async static Task<bool> EditCardholder(EditCardholder cardholder, string cardholderID, string firstName, string lastName, string accessGrpName, string accessGrpID, string company_name, string endDate, string gender, string VIP, string addTime, string tower)
        {
            Ping ping;
            IPAddress address;
            PingReply pong;
            int countforStop = 0;
            do
            {
                countforStop = countforStop + 1;
                ping = new Ping();
                address = IPAddress.Parse(connString.GAL_Server_IP_address);
                pong = ping.Send(address);
                if (pong.Status == IPStatus.Success)
                {
                    try
                    {
                        Authentication._client();
                        string card = JsonConvert.SerializeObject(cardholder);
                        cardholderManagement.logger.Info("Edit card (input): " + card);
                        var content = new StringContent(card, Encoding.UTF8, "application/json");
                        content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                        var method = new HttpMethod("PATCH");
                        var request = new HttpRequestMessage(method, "/api/cardholders/" + cardholderID)
                        {
                            Content = content
                        };
                        HttpResponseMessage response = await Authentication._client().SendAsync(request);

                        if (response.IsSuccessStatusCode)
                        {
                            if (sql.State == ConnectionState.Closed)
                                sql.Open();
                            SqlCommand sqlcmdx90 = new SqlCommand("UPDATE dbo.cardholder SET firstName = '" + firstName + "', lastName = '" + lastName + "', accessGrpID = '" + accessGrpID + "', accessGrpName = '" + accessGrpName + "', company_name = '" + company_name + "',endDate = '" + endDate + "', Gender = '" + gender + "',VIP = '" + VIP + "' WHERE cardholderID = '" + cardholderID + "' and System = 'GAL' and tower = '" + tower + "'", sql);
                            sqlcmdx90.ExecuteNonQuery();
                            SqlCommand sqlcmdlog = new SqlCommand("UPDATE dbo.log_GAL SET Success_time = @DatetimeNow WHERE cardholderID = '" + cardholderID + "' and [Action] = 'EDIT' and Add_time = '" + addTime + "' and Tower = '" + tower + "'", sql);
                            sqlcmdlog.Parameters.AddWithValue("@DatetimeNow ", DateTime.Now);
                            sqlcmdlog.ExecuteNonQuery();
                            SqlCommand sqlcmdupdate = new SqlCommand("UPDATE dbo.update_GAL SET Success_time = @DatetimeNow WHERE cardholderID = '" + cardholderID + "' and [Action] = 'EDIT' and Add_time = '" + addTime + "'  and Tower = '" + tower + "'", sql);
                            sqlcmdupdate.Parameters.AddWithValue("@DatetimeNow ", DateTime.Now);
                            sqlcmdupdate.ExecuteNonQuery();
                            sql.Close();
                            _msg = "Cardholder - (" + cardholderID + ") is edited via Gallagher API. Status code:" + "\r\n" + response.ReasonPhrase;
                            return true;
                        }
                        else
                        {
                            if (sql.State == ConnectionState.Closed)
                                sql.Open();
                            SqlCommand sqlcmdlog = new SqlCommand("UPDATE dbo.log_GAL SET Fail_time = @DatetimeNow WHERE cardholderID = '" + cardholderID + "' and [Action] = 'EDIT' and Add_time = '" + addTime + "'  and Tower = '" + tower + "'", sql);
                            sqlcmdlog.Parameters.AddWithValue("@DatetimeNow ", DateTime.Now);
                            sqlcmdlog.ExecuteNonQuery();
                            SqlCommand sqlcmdupdate = new SqlCommand("UPDATE dbo.update_GAL SET Fail_time = @DatetimeNow WHERE cardholderID = '" + cardholderID + "' and [Action] = 'EDIT' and Add_time = '" + addTime + "'  and Tower = '" + tower + "'", sql);
                            sqlcmdupdate.Parameters.AddWithValue("@DatetimeNow ", DateTime.Now);
                            sqlcmdupdate.ExecuteNonQuery();
                            sql.Close();
                            _msg = "Failed to edit cardholder  - (" + cardholderID + "). Status code:" + "\r\n" + response.ReasonPhrase;
                            return false;
                        }
                    }
                    catch (Exception err)
                    {
                        logger.Error(err, "Failure in adding cardholder towards GAL API");
                        return false;
                    }
                }
                else
                {
                    logger.Error("Failure in adding cardholder towards GAL API: Connection Failure to GAL server!");
                    return false;
                }
            } while (pong.Status != IPStatus.Success && countforStop < 30);
        }

        public static bool delCompany(string Company_name, string addTime, string tower, List<string> cardholderList)
        {
            Ping ping;
            IPAddress address;
            PingReply pong;
            int countforStop = 0;
            do
            {
                countforStop = countforStop + 1;
                ping = new Ping();
                address = IPAddress.Parse(connString.GAL_Server_IP_address);
                pong = ping.Send(address);
                if (pong.Status == IPStatus.Success)
                {
                    try
                    {
                        Authentication._client();
                        if (sql.State == ConnectionState.Closed)
                            sql.Open();
                        //SqlCommand sqlcmd = new SqlCommand("SELECT cardholderID FROM dbo.cardholder WHERE Company_name = '" + Company_name + "' and System = 'GAL' and Tower = '" + tower + "'", sql);
                        //sqlcmd.ExecuteNonQuery();
                        //List<string> deletedCardholderID = new List<string>();
                        //using (SqlDataReader reader = sqlcmd.ExecuteReader())
                        //{
                        //    while (reader.Read())
                        //    {
                        //        for (int i = 0; i < reader.FieldCount; i++)
                        //        {
                        //            deletedCardholderID.Add(reader[i].ToString());
                        //        }
                        //    }
                        //    reader.Close();
                        //}
                        for (int i = 0; i < cardholderList.Count; i++)
                        {
                            var responseCompany = Authentication._client().DeleteAsync("api/cardholders/" + cardholderList[i]).Result;
                            if (responseCompany.IsSuccessStatusCode)
                            {
                                SqlCommand del = new SqlCommand("DELETE FROM dbo.cardholder WHERE cardholderID = '" + cardholderList[i] + "'  and System = 'GAL' and Tower = '" + tower + "'", sql);
                                del.ExecuteNonQuery();
                                cardholderManagement.logger.Info("Delete Cardholder - " + cardholderList[i] + " from " + Company_name + " Successfully!");
                            }
                            else
                            {
                                if (sql.State == ConnectionState.Closed)
                                    sql.Open();
                                SqlCommand del_log1 = new SqlCommand("UPDATE dbo.log_GAL SET Fail_time = @DatetimeNow WHERE Company_name = '" + Company_name + "' and [Action] = 'DC' and Add_time = '" + addTime + "'", sql);
                                del_log1.Parameters.AddWithValue("@DatetimeNow ", DateTime.Now);
                                del_log1.ExecuteNonQuery();
                                SqlCommand del_update1 = new SqlCommand("UPDATE dbo.update_GAL SET Fail_time = @DatetimeNow WHERE Company_name = '" + Company_name + "' and [Action] = 'DC' and Add_time = '" + addTime + "'", sql);
                                del_update1.Parameters.AddWithValue("@DatetimeNow ", DateTime.Now);
                                del_update1.ExecuteNonQuery();
                                sql.Close();
                                _msg = "Failed to delete cardholders from " + Company_name + "\r\n" + "start from cardholderID: " + cardholderList[i] + responseCompany.ReasonPhrase;
                                return false;
                            }
                        }
                        SqlCommand del_company = new SqlCommand("DELETE FROM dbo.Company WHERE Company_name = '" + Company_name + "' and System = 'GAL' and Tower = '" + tower + "'", sql);
                        del_company.ExecuteNonQuery();
                        SqlCommand del_log = new SqlCommand("UPDATE dbo.log_GAL SET Success_time = @DatetimeNow WHERE Company_name = '" + Company_name + "' and [Action] = 'DC' and Add_time = '" + addTime + "'", sql);
                        del_log.Parameters.AddWithValue("@DatetimeNow ", DateTime.Now);
                        del_log.ExecuteNonQuery();
                        SqlCommand del_update = new SqlCommand("UPDATE dbo.update_GAL SET Success_time = @DatetimeNow WHERE Company_name = '" + Company_name + "' and [Action] = 'DC' and Add_time = '" + addTime + "'", sql);
                        del_update.Parameters.AddWithValue("@DatetimeNow ", DateTime.Now);
                        del_update.ExecuteNonQuery();
                        sql.Close();
                        _msg = "All cardholders from '" + Company_name + "' are deleted";
                        return true;
                    }
                    catch (Exception err)
                    {
                        logger.Error(err, "Failure in deleting company towards GAL API");
                        sql.Close();
                        return false;
                    }
                }
                else
                {
                    logger.Error("Failure in deleting company towards GAL API: Connection Failure to GAL server!");
                    return false;
                }
            } while (pong.Status != IPStatus.Success && countforStop < 30);
        }
        public async void Start()
        {
            try
            {
                sql = connString.getConnString();
                ping = new Ping();
                address = IPAddress.Parse(connString.GAL_Server_IP_address);
                pong = ping.Send(address);
                if (pong.Status == IPStatus.Success)
                {
                    logger.Info("Gallagher API Service start!");
                    //DailyTime();
                    _timer.Start();
                    _timer2.Start();
                    _timer3.Start();
                    if (await DoorChoice.GetDoorchoice() == true)
                    {
                        if (await CardType.GetcardType() == true)
                        {
                            if (await AccessGroup.GetaccessGrpchoice() == true)
                            {
                                if (await LoadOldCardholders.GetCardholder() == true)
                                {
                                    await eventViewer.getEvent();
                                }
                            }
                        }
                    }
                }
                else
                {
                    logger.Error("Failure in start Gallagher API Service: Connection Failure to GAL server!");
                }
            }
            catch (Exception err)
            {
                logger.Error(err, "Failure in start Gallagher API Service");
            }
        }

        public void Stop()
        {
            logger.Info("Gallagher API Service stop!");
            _timer.Stop();
            _timer2.Stop();
            _timer3.Stop();
        }
    }
}
