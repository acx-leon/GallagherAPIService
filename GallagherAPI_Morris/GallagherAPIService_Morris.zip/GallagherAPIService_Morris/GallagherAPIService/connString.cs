﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GallagherAPIService
{
    public class connString
    {
        public static string ACS_DB_IP_address;
        public static string ACS_DB_name;
        public static string ACS_DB_uid;
        public static string ACS_DB_pwd;
        public static string GAL_Server_IP_address;
        static string Tower = ConfigurationManager.AppSettings["Tower"].ToString();
        public static SqlConnection getConnString()
        {
            string connStr = ConfigurationManager.ConnectionStrings["defaultConnString"].ConnectionString;
            SqlConnection sql = new SqlConnection(connStr);
            if (sql.State == ConnectionState.Closed)
                sql.Open();
            SqlCommand sqlcmd = new SqlCommand("select ACS_DB_IP_address,ACS_DB_name,ACS_DB_uid,ACS_DB_pwd,GAL_Server_IP_address From Server_info where Tower = '" + Tower + "'", sql);
            SqlDataReader mySQLDataReader = sqlcmd.ExecuteReader();
            while (mySQLDataReader.Read())
            {
                ACS_DB_IP_address = mySQLDataReader[0].ToString();
                ACS_DB_name = mySQLDataReader[1].ToString();
                ACS_DB_uid = mySQLDataReader[2].ToString();
                ACS_DB_pwd = mySQLDataReader[3].ToString();
                GAL_Server_IP_address = mySQLDataReader[4].ToString();
            }
            mySQLDataReader.Close();
            sql.Close();
            SqlConnection sqlC = new SqlConnection("server=" + ACS_DB_IP_address + "; Database=" + ACS_DB_name + ";uid=" + ACS_DB_uid + ";pwd=" + ACS_DB_pwd + "");
            Console.WriteLine("server=" + ACS_DB_IP_address + "; Database=" + ACS_DB_name + ";uid=" + ACS_DB_uid + ";pwd=" + ACS_DB_pwd + "");
            Console.WriteLine(GAL_Server_IP_address);
            return sqlC;
        }
    }
}
