﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GallagherAPIService.db
{
    public class HKLandACS
    {
        public class AccessGroup
        {
            public static int accessGrpIDExists(string id, string Tower)
            {
                int count;
                using (SqlConnection conn = connString.getConnString())
                {
                    string query = "SELECT count(*) FROM dbo.AccessGrp where accessGrpID = @id AND Tower = @Tower";
                    SqlCommand sqlcmd = new SqlCommand(query, conn);
                    sqlcmd.CommandType = CommandType.Text;
                    sqlcmd.Parameters.AddWithValue("@id", id);
                    sqlcmd.Parameters.AddWithValue("@Tower", Tower);
                    conn.Open();
                    count = (int)sqlcmd.ExecuteScalar();
                    conn.Close();
                }
                return count;
            }
            public static void addAccessGrp(string Tower, string accessGrpName, string accessGrpID)
            {
                using (SqlConnection conn = connString.getConnString())
                {
                    string query = "addAccessGrp";
                    SqlCommand sqlcmd = new SqlCommand(query, conn);
                    sqlcmd.CommandType = CommandType.StoredProcedure;
                    sqlcmd.Parameters.AddWithValue("@Tower", Tower);
                    sqlcmd.Parameters.AddWithValue("@accessGrpName", accessGrpName);
                    sqlcmd.Parameters.AddWithValue("@accessGrpID", accessGrpID);
                    conn.Open();
                    sqlcmd.ExecuteNonQuery();
                    conn.Close();
                }
            }

            public static DataTable QueryAccessGrp(string Tower)
            {
                using (SqlConnection conn = connString.getConnString())
                {
                    string[] querys = new string[]
                    {
                    "select accessGrpID FROM dbo.AccessGrp",
                    "  where Tower=@Tower"
                    };
                    string query = string.Join(" ", querys);
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Connection = conn;
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@Tower", Tower);
                    DataTable dt = new DataTable();
                    SqlDataAdapter adp = new SqlDataAdapter(cmd);
                    adp.Fill(dt);
                    return dt;
                }
            }

            public static void DeleteAccessGrp(string accessGrpID, string Tower)
            {
                using (SqlConnection conn = connString.getConnString())
                {
                    string sql = "delete FROM dbo.AccessGrp where accessGrpID = @accessGrpID AND Tower = @Tower ";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@accessGrpID", accessGrpID);
                    cmd.Parameters.AddWithValue("@Tower", Tower);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                }
            }
        }

        public class AccessZone
        {
            public static int accessZoneIDExists(string id, string Tower)
            {
                int count;
                using (SqlConnection conn = connString.getConnString())
                {
                    string query = "SELECT count(*) FROM dbo.AccessZone where accessZoneID = @id AND Tower = @Tower";
                    SqlCommand sqlcmd = new SqlCommand(query, conn);
                    sqlcmd.CommandType = CommandType.Text;
                    sqlcmd.Parameters.AddWithValue("@id", id);
                    sqlcmd.Parameters.AddWithValue("@Tower", Tower);
                    conn.Open();
                    count = (int)sqlcmd.ExecuteScalar();
                    conn.Close();

                }
                return count;
            }
            public static void addAccessZone(string Tower, string accessZoneName, string accessZoneID)
            {
                using (SqlConnection conn = connString.getConnString())
                {
                    string query = "addAccessZone";
                    SqlCommand sqlCommand = new SqlCommand(query, conn);
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    sqlCommand.Parameters.AddWithValue("@Tower", Tower);
                    sqlCommand.Parameters.AddWithValue("@accessZoneName", accessZoneName);
                    sqlCommand.Parameters.AddWithValue("@accessZoneID", accessZoneID);
                    conn.Open();
                    sqlCommand.ExecuteNonQuery();
                    conn.Close();
                }
            }

            public static DataTable QueryZone(string Tower)
            {
                using (SqlConnection conn = connString.getConnString())
                {
                    string query = "select accessZoneID FROM dbo.AccessZone where Tower = @Tower ";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Connection = conn;
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@Tower", Tower);
                    DataTable dt = new DataTable();
                    SqlDataAdapter adp = new SqlDataAdapter(cmd);
                    adp.Fill(dt);
                    return dt;
                }
            }

            public static void DeleteZone(string accessZoneID, string Tower)
            {
                using (SqlConnection conn = connString.getConnString())
                {
                    string sql = "delete FROM dbo.AccessZone where accessZoneID = @accessZoneID AND Tower = @Tower ";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@accessZoneID", accessZoneID);
                    cmd.Parameters.AddWithValue("@Tower", Tower);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                }
            }


        }

        public class DoorChoice
        {
            public static int DoorIDExists(string id, string Tower)
            {
                int count;
                using (SqlConnection conn = connString.getConnString())
                {
                    string query = "SELECT count(*) FROM dbo.Door where doorID = @id AND Tower = @Tower";
                    SqlCommand sqlcmd = new SqlCommand(query, conn);
                    sqlcmd.CommandType = CommandType.Text;
                    sqlcmd.Parameters.AddWithValue("@id", id);
                    sqlcmd.Parameters.AddWithValue("@Tower", Tower);
                    conn.Open();
                    count = (int)sqlcmd.ExecuteScalar();
                    conn.Close();

                }
                return count;
            }
            public static void addDoor(string Tower, string doorName, string doorID)
            {
                using (SqlConnection conn = connString.getConnString())
                {
                    string query = "addDoor";
                    SqlCommand sqlcmd = new SqlCommand(query, conn);
                    sqlcmd.CommandType = CommandType.StoredProcedure;
                    sqlcmd.Parameters.AddWithValue("@Tower", Tower);
                    sqlcmd.Parameters.AddWithValue("@doorName", doorName);
                    sqlcmd.Parameters.AddWithValue("@doorID", doorID);
                    conn.Open();
                    sqlcmd.ExecuteNonQuery();
                    conn.Close();
                }
            }

            public static DataTable QueryDoor(string Tower)
            {
                using (SqlConnection conn = connString.getConnString())
                {
                    string query = "select doorID FROM dbo.Door where Tower = @Tower ";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Connection = conn;
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@Tower", Tower);
                    DataTable dt = new DataTable();
                    SqlDataAdapter adp = new SqlDataAdapter(cmd);
                    adp.Fill(dt);
                    return dt;
                }
            }

            public static void DeleteDoor(string doorID, string Tower)
            {
                using (SqlConnection conn = connString.getConnString())
                {
                    string sql = "delete FROM dbo.Door where doorID = @doorID AND Tower = @Tower ";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@doorID", doorID);
                    cmd.Parameters.AddWithValue("@Tower", Tower);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                }
            }
        }

        public class CardType
        {
            public static int CardTypeIDExists(string id, string Tower)
            {
                int count;
                using (SqlConnection conn = connString.getConnString())
                {
                    string query = "SELECT count(*) FROM dbo.CardType where cardTypeID = @id AND Tower = @Tower";
                    SqlCommand sqlcmd = new SqlCommand(query, conn);
                    sqlcmd.CommandType = CommandType.Text;
                    sqlcmd.Parameters.AddWithValue("@id", id);
                    sqlcmd.Parameters.AddWithValue("@Tower", Tower);
                    conn.Open();
                    count = (int)sqlcmd.ExecuteScalar();
                    conn.Close();

                }
                return count;
            }
            public static void allcardTypesGet(string System, string Tower, string cardTypeName, string cardTypeID)
            {
                try
                {
                    using (SqlConnection conn = connString.getConnString())
                    {
                        string query = "allcardTypesGet";
                        SqlCommand sqlcmd = new SqlCommand(query, conn);
                        sqlcmd.CommandType = CommandType.StoredProcedure;
                        sqlcmd.Parameters.AddWithValue("@System", System);
                        sqlcmd.Parameters.AddWithValue("@Tower", Tower);
                        sqlcmd.Parameters.AddWithValue("@cardTypeName", cardTypeName);
                        sqlcmd.Parameters.AddWithValue("@cardTypeID", cardTypeID);
                        conn.Open();
                        sqlcmd.ExecuteNonQuery();
                        conn.Close();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            public static DataTable QueryCardType(string Tower)
            {
                using (SqlConnection conn = connString.getConnString())
                {
                    string query = "select cardTypeID FROM dbo.CardType where Tower = @Tower ";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Connection = conn;
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@Tower", Tower);
                    DataTable dt = new DataTable();
                    SqlDataAdapter adp = new SqlDataAdapter(cmd);
                    adp.Fill(dt);
                    return dt;
                }
            }
            public static void DeleteCardType(string cardTypeID, string Tower)
            {
                using (SqlConnection conn = connString.getConnString())
                {
                    string sql = "delete FROM dbo.CardType where cardTypeID = @cardTypeID AND Tower = @Tower ";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@cardTypeID", cardTypeID);
                    cmd.Parameters.AddWithValue("@Tower", Tower);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                }
            }
        }
        public class LoadOldCardholders
        {
            public static int CardholderIDExists(string id, string Tower)
            {
                int count;
                using (SqlConnection conn = connString.getConnString())
                {
                    string query = "SELECT count(*) FROM dbo.cardholder where cardholderID = @id AND Tower = @Tower";
                    SqlCommand sqlcmd = new SqlCommand(query, conn);
                    sqlcmd.CommandType = CommandType.Text;
                    sqlcmd.Parameters.AddWithValue("@id", id);
                    sqlcmd.Parameters.AddWithValue("@Tower", Tower);
                    conn.Open();
                    count = (int)sqlcmd.ExecuteScalar();
                    conn.Close();

                }
                return count;
            }
            public static DataTable QueryOldCardholders(string Tower)
            {
                using (SqlConnection conn = connString.getConnString())
                {
                    string query = "select cardholderID FROM dbo.cardholder where Tower = @Tower ";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Connection = conn;
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@Tower", Tower);
                    DataTable dt = new DataTable();
                    SqlDataAdapter adp = new SqlDataAdapter(cmd);
                    adp.Fill(dt);
                    return dt;
                }
            }
            public static void DeleteOldCardholders(string cardholderID, string Tower)
            {
                using (SqlConnection conn = connString.getConnString())
                {
                    string sql = "delete FROM dbo.cardholder where cardholderID = @cardholderID AND Tower = @Tower ";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@cardholderID", cardholderID);
                    cmd.Parameters.AddWithValue("@Tower", Tower);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                }
            }
        }

        public class Company
        {
            public static int CompanyNameExists(string Company_name, string Tower)
            {
                int count;
                using (SqlConnection conn = connString.getConnString())
                {
                    string query = "SELECT count(*) FROM dbo.Company where Company_name = @Company_name AND Tower = @Tower";
                    SqlCommand sqlcmd = new SqlCommand(query, conn);
                    sqlcmd.CommandType = CommandType.Text;
                    sqlcmd.Parameters.AddWithValue("@Company_name", Company_name);
                    sqlcmd.Parameters.AddWithValue("@Tower", Tower);
                    conn.Open();
                    count = (int)sqlcmd.ExecuteScalar();
                    conn.Close();

                }
                return count;
            }
            public static void AddOldCompany(string System, string Tower, string Company_name)
            {
                try
                {
                    using (SqlConnection conn = connString.getConnString())
                    {
                        string query = "addoldCompany";
                        SqlCommand sqlcmd = new SqlCommand(query, conn);
                        sqlcmd.CommandType = CommandType.StoredProcedure;
                        sqlcmd.Parameters.AddWithValue("@System", System);
                        sqlcmd.Parameters.AddWithValue("@Tower", Tower);
                        sqlcmd.Parameters.AddWithValue("@cardTypeName", Company_name);
                        conn.Open();
                        sqlcmd.ExecuteNonQuery();
                        conn.Close();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            public static DataTable QueryCompany(string Tower)
            {
                using (SqlConnection conn = connString.getConnString())
                {
                    string query = "select Company_name FROM dbo.Company where Tower = @Tower ";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Connection = conn;
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@Tower", Tower);
                    DataTable dt = new DataTable();
                    SqlDataAdapter adp = new SqlDataAdapter(cmd);
                    adp.Fill(dt);
                    return dt;
                }
            }
            public static void DeleteCompany(string Company_name, string System, string Tower)
            {
                using (SqlConnection conn = connString.getConnString())
                {
                    string sql = "delete FROM dbo.Company where Company_name NOT IN @Company_name AND System=@System AND Tower = @Tower ";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@Company_name", Company_name);
                    cmd.Parameters.AddWithValue("@System", System);
                    cmd.Parameters.AddWithValue("@Tower", Tower);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                }
            }
        }
        public class EventViewer
        {
            public static DataTable QueryEvent()
            {
                using (SqlConnection conn = connString.getConnString())
                {
                    string query = "SELECT top 1 id FROM dbo.GAL_Event Order By time DESC";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Connection = conn;
                    cmd.CommandType = CommandType.Text;
                    DataTable dt = new DataTable();
                    SqlDataAdapter adp = new SqlDataAdapter(cmd);
                    adp.Fill(dt);
                    return dt;
                }
            }
        }
        /*public static void InsertEvent(string Tower, string href, string id, string time, string message, string occurrences, string priority, string alarm_href, string alarm_state, string details, 
            string source_href, string source_id, string source_name, string group_id, string group_name, string type_id, string type_name, string division_id, string division_href, 
            string cardholder_href, string cardholder_id, string cardholder_name, string cardholder_firstName, string cardholder_lastName, string entryAccessZone_href, string entryAccessZone_name, 
            string entryAccessZone_id, string exitAccessZone_href, string exitAccessZone_name, string exitAccessZone_id, string door_name, string door_id, string card_facilityCode, string card_number, 
            string card_issueLevel, string lastOcurrenceTime, string Operator_cardholderID, string AccessGrp_cardholderID)
        {
            using (SqlConnection conn = connString.getConnString())
            {
                string query = "Insert into dbo.GAL_Event VALUES(@Tower,@href,@id,@time,@message,@occurrences,@priority,@alarm_href,@alarm_state,@details,@source_href,@source_id,@source_name,@group_id,@group_name,@type_id,@type_name,@division_id,@division_href,@cardholder_href,@cardholder_id,@cardholder_name,@cardholder_firstName,@cardholder_lastName,@entryAccessZone_href,@entryAccessZone_name,@entryAccessZone_id,@exitAccessZone_href,@exitAccessZone_name,@exitAccessZone_id,@door_name,@door_id,@card_facilityCode,@card_number,@card_issueLevel,@lastOccurrenceTime,@Operator_cardholderID,@AccessGrp_cardholderID)";
                SqlCommand sqlcmd = new SqlCommand(query, conn);
                sqlcmd.Parameters.AddWithValue("@Tower", Tower ?? Convert.DBNull);
                sqlcmd.Parameters.AddWithValue("@href", href ?? Convert.DBNull);
                sqlcmd.Parameters.AddWithValue("@id", id ?? Convert.DBNull);
                sqlcmd.Parameters.AddWithValue("@time", time ?? Convert.DBNull);
                sqlcmd.Parameters.AddWithValue("@message", message ?? Convert.DBNull);
                sqlcmd.Parameters.AddWithValue("@occurrences", occurrences ?? Convert.DBNull);
                sqlcmd.Parameters.AddWithValue("@priority", priority ?? Convert.DBNull);
                sqlcmd.Parameters.AddWithValue("@alarm_href", alarm_href ?? Convert.DBNull);
                sqlcmd.Parameters.AddWithValue("@alarm_state", alarm_state ?? Convert.DBNull);
                sqlcmd.Parameters.AddWithValue("@details", details ?? Convert.DBNull);
                sqlcmd.Parameters.AddWithValue("@source_href", source_href ?? Convert.DBNull);
                sqlcmd.Parameters.AddWithValue("@source_id", source_id ?? Convert.DBNull);
                sqlcmd.Parameters.AddWithValue("@source_name", source_name ?? Convert.DBNull);
                sqlcmd.Parameters.AddWithValue("@group_id", group_id) ?? Convert.DBNull);
                sqlcmd.Parameters.AddWithValue("@group_name", group_name ?? Convert.DBNull);
                sqlcmd.Parameters.AddWithValue("@type_id", type_id) ?? Convert.DBNull);
                sqlcmd.Parameters.AddWithValue("@type_name", ((object)dataEvent.type.name) ?? DBNull.Value);
                sqlcmd.Parameters.AddWithValue("@division_id", ((object)dataEvent.division.id) ?? DBNull.Value);
                sqlcmd.Parameters.AddWithValue("@division_href", ((object)dataEvent.division.href) ?? DBNull.Value);
                sqlcmd.Parameters.AddWithValue("@cardholder_href", ((object)cardholder_href) ?? DBNull.Value);
                sqlcmd.Parameters.AddWithValue("@cardholder_id", ((object)cardholder_id) ?? DBNull.Value);
                sqlcmd.Parameters.AddWithValue("@cardholder_name", ((object)cardholder_name) ?? DBNull.Value);
                sqlcmd.Parameters.AddWithValue("@cardholder_firstName", ((object)cardholder_firstName) ?? DBNull.Value);
                sqlcmd.Parameters.AddWithValue("@cardholder_lastName", ((object)cardholder_lastName) ?? DBNull.Value);
                sqlcmd.Parameters.AddWithValue("@entryAccessZone_href", ((object)entryAccessZone_href) ?? DBNull.Value);
                sqlcmd.Parameters.AddWithValue("@entryAccessZone_name", ((object)entryAccessZone_name) ?? DBNull.Value);
                sqlcmd.Parameters.AddWithValue("@entryAccessZone_id", ((object)entryAccessZone_id) ?? DBNull.Value);
                sqlcmd.Parameters.AddWithValue("@exitAccessZone_href", ((object)exitAccessZone_href) ?? DBNull.Value);
                sqlcmd.Parameters.AddWithValue("@exitAccessZone_name", ((object)exitAccessZone_name) ?? DBNull.Value);
                sqlcmd.Parameters.AddWithValue("@exitAccessZone_id", ((object)exitAccessZone_id) ?? DBNull.Value);
                sqlcmd.Parameters.AddWithValue("@door_name", ((object)door_name) ?? DBNull.Value);
                sqlcmd.Parameters.AddWithValue("@door_id", ((object)door_id) ?? DBNull.Value);
                sqlcmd.Parameters.AddWithValue("@card_facilityCode", ((object)card_facilityCode) ?? DBNull.Value);
                sqlcmd.Parameters.AddWithValue("@card_number", ((object)card_number) ?? DBNull.Value);
                sqlcmd.Parameters.AddWithValue("@card_issueLevel", ((object)card_issueLevel) ?? DBNull.Value);
                sqlcmd.Parameters.AddWithValue("@lastOccurrenceTime", ((object)dataEvent.lastOccurrenceTime) ?? DBNull.Value);
                sqlcmd.Parameters.AddWithValue("@Operator_cardholderID", ((object)Operator_cardholder_id) ?? DBNull.Value);
                sqlcmd.Parameters.AddWithValue("@AccessGrp_cardholderID", ((object)AccessGroup_cardholder_id) ?? DBNull.Value);

            }
        }
    }*/
    }
}
