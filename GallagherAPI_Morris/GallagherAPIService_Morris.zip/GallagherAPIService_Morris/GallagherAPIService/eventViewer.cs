﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace GallagherAPIService
{
    public class eventViewer
    {
        static SqlConnection sql = connString.getConnString();
        static string Tower = ConfigurationManager.AppSettings["Tower"].ToString();
        static string alarm_href = "";
        static string alarm_state = "";
        static string cardholder_href = "";
        static string cardholder_id = "";
        static string cardholder_name = "";
        static string cardholder_firstName = "";
        static string cardholder_lastName = "";
        static string entryAccessZone_href = "";
        static string entryAccessZone_name = "";
        static string entryAccessZone_id = "";
        static string exitAccessZone_href = "";
        static string exitAccessZone_name = "";
        static string exitAccessZone_id = "";
        static string door_name = "";
        static string door_id = "";
        static string card_facilityCode = "";
        static string card_number = "";
        static string card_issueLevel = "";
        static string Operator_cardholder_id = "";
        static string AccessGroup_cardholder_id = "";
        static List<string> event_id = new List<string>();
        static string resultEvent = "";
        static string currentHref = "";
        static int num_of_event;

        //static string getEventAPI = ConfigurationManager.AppSettings["getEventAPI"].ToString();

        public static async Task getEvent()
        {
            Authentication._client();
            try
            {
                event_id.Clear();
                //if (sql.State == ConnectionState.Closed)
                //    sql.Open();
                //SqlDataAdapter dacheck = new SqlDataAdapter("SELECT top 1 id FROM dbo.GAL_Event Order By time DESC", sql);
                //DataTable dtcheck = new DataTable();
                //dacheck.Fill(dtcheck);
                //sql.Close();
                DataTable dtcheck = db.HKLandACS.EventViewer.QueryEvent();

                if (dtcheck.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtcheck.Rows)
                    {
                        string test = dr["id"].ToString();
                        currentHref = "/api/events?pos=" + dr["id"].ToString() + "&previous=False&top=1000&after=2020-12-31Z&before=2021-05-06Z";
                        cardholderManagement.logger.Info("1st getting event href: " + currentHref);
                    }
                }
                else
                {
                    //currentHref = "/api/events?pos=0&previous=False&top=10000";
                    //cardholderManagement.logger.Info("1st getting event href: " + currentHref);
                    currentHref = "/api/events?previous=False&after=2020-12-31Z&before=2021-05-06Z";
                    cardholderManagement.logger.Info("1st getting event href: " + currentHref);
                }

                do
                {
                    //HttpResponseMessage responseID;
                    //using (Authentication._client())
                    //{
                    //    responseID = await Authentication._client().GetAsync(currentHref.ToString());
                    //}
                    Authentication._client();
                    Console.WriteLine(currentHref.ToString());
                    HttpResponseMessage responseID = await Authentication._client().GetAsync(currentHref.ToString());
                    if (responseID.IsSuccessStatusCode)
                    {
                        resultEvent = await responseID.Content.ReadAsStringAsync();
                        var dataID = JsonConvert.DeserializeObject<eventsConfig>(resultEvent);
                        num_of_event = dataID.events.Count;
                        if (dataID.events.Count == 0)
                        {
                            cardholderManagement.logger.Info("No Extra Event!");
                        }
                        else
                        {
                            /*if (dataID.events.Count > 0)
                            {
                                for (int i = 0; i < dataID.events.Count; i++)
                                {
                                    //HttpResponseMessage responseEvent;
                                    //using (Authentication._client())
                                    //{
                                    //    responseEvent = await Authentication._client().GetAsync("/api/events/" + event_id[i]);
                                    //}
                                    HttpResponseMessage responseEvent = await Authentication._client().GetAsync("/api/events/" + dataID.events[i].id);
                                    if (responseEvent.IsSuccessStatusCode)
                                    {
                                        string resultEvent1 = await responseEvent.Content.ReadAsStringAsync();
                                        var dataEvent = JsonConvert.DeserializeObject<Example>(resultEvent1);
                                        cardholderManagement.logger.Info("Get Events:" + resultEvent1);
                                        if (Regex.IsMatch(resultEvent1, "\"alarm\""))
                                        {
                                            alarm_href = dataEvent.alarm.href;
                                            alarm_state = dataEvent.alarm.state;
                                        }
                                        else
                                        {
                                            alarm_href = null;
                                            alarm_state = null;
                                        }

                                        if (Regex.IsMatch(resultEvent1, "\"cardholder\""))
                                        {
                                            cardholder_href = dataEvent.cardholder.href;
                                            cardholder_id = dataEvent.cardholder.id;
                                            cardholder_name = dataEvent.cardholder.name;
                                            cardholder_firstName = dataEvent.cardholder.firstName;
                                            cardholder_lastName = dataEvent.cardholder.lastName;
                                        }
                                        else
                                        {
                                            cardholder_href = null;
                                            cardholder_id = null;
                                            cardholder_name = null;
                                            cardholder_firstName = null;
                                            cardholder_lastName = null;
                                        }

                                        if (Regex.IsMatch(resultEvent1, "\"entryAccessZone\""))
                                        {
                                            entryAccessZone_href = dataEvent.entryAccessZone.href;
                                            entryAccessZone_name = dataEvent.entryAccessZone.name;
                                            entryAccessZone_id = dataEvent.entryAccessZone.id;
                                        }
                                        else
                                        {
                                            entryAccessZone_href = null;
                                            entryAccessZone_name = null;
                                            entryAccessZone_id = null;
                                        }

                                        if (Regex.IsMatch(resultEvent1, "\"exitAccessZone\""))
                                        {
                                            exitAccessZone_href = dataEvent.exitAccessZone.href;
                                            exitAccessZone_name = dataEvent.exitAccessZone.name;
                                            exitAccessZone_id = dataEvent.exitAccessZone.id;
                                        }
                                        else
                                        {
                                            exitAccessZone_href = null;
                                            exitAccessZone_name = null;
                                            exitAccessZone_id = null;
                                        }

                                        if (Regex.IsMatch(resultEvent1, "\"door\""))
                                        {
                                            door_name = dataEvent.door.name;
                                            door_id = dataEvent.door.href.ToString().Split('/')[5];
                                        }
                                        else
                                        {
                                            door_name = null;
                                            door_id = null;
                                        }

                                        if (Regex.IsMatch(resultEvent1, "\"card\""))
                                        {
                                            card_facilityCode = dataEvent.card.facilityCode;
                                            card_number = dataEvent.card.number;
                                            card_issueLevel = dataEvent.card.issueLevel.ToString();
                                        }
                                        else
                                        {
                                            card_facilityCode = null;
                                            card_number = null;
                                            card_issueLevel = null;
                                        }

                                        if (Regex.IsMatch(resultEvent1, "\"operator\""))
                                        {
                                            Operator_cardholder_id = dataEvent.operator2.href.ToString().Split('/')[5];
                                        }
                                        else
                                        {
                                            Operator_cardholder_id = null;
                                        }

                                        if (Regex.IsMatch(resultEvent1, "\"accessGroup\""))
                                        {
                                            AccessGroup_cardholder_id = dataEvent.accessGroup.href.ToString().Split('/')[5];
                                        }
                                        else
                                        {
                                            AccessGroup_cardholder_id = null;
                                        }

                                        CultureInfo culture = new CultureInfo("zh-HK");
                                        DateTime tempDate = Convert.ToDateTime(dataEvent.time, culture);
                                        string date = tempDate.ToString("yyyy-MM-dd HH:mm:ss.fff");

                                        if (sql.State == ConnectionState.Closed)
                                            sql.Open();

                                        using (SqlCommand sqlcmd = new SqlCommand("Insert into dbo.GAL_Event VALUES(@Tower,@href,@id,@time,@message,@occurrences,@priority,@alarm_href,@alarm_state,@details,@source_href,@source_id,@source_name,@group_id,@group_name,@type_id,@type_name,@division_id,@division_href,@cardholder_href,@cardholder_id,@cardholder_name,@cardholder_firstName,@cardholder_lastName,@entryAccessZone_href,@entryAccessZone_name,@entryAccessZone_id,@exitAccessZone_href,@exitAccessZone_name,@exitAccessZone_id,@door_name,@door_id,@card_facilityCode,@card_number,@card_issueLevel,@lastOccurrenceTime,@Operator_cardholderID,@AccessGrp_cardholderID)", sql))
                                        {
                                            sqlcmd.Parameters.AddWithValue("@Tower", ((object)Tower) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@href", ((object)dataEvent.href) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@id", ((object)dataEvent.id) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@time", ((object)date) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@message", ((object)dataEvent.message) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@occurrences", ((object)dataEvent.occurrences.ToString()) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@priority", ((object)dataEvent.priority.ToString()) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@alarm_href", ((object)alarm_href) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@alarm_state", ((object)alarm_state) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@details", ((object)dataEvent.details) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@source_href", ((object)dataEvent.source.href) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@source_id", ((object)dataEvent.source.id) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@source_name", ((object)dataEvent.source.name) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@group_id", ((object)dataEvent.group.id) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@group_name", ((object)dataEvent.group.name) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@type_id", ((object)dataEvent.type.id) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@type_name", ((object)dataEvent.type.name) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@division_id", ((object)dataEvent.division.id) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@division_href", ((object)dataEvent.division.href) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@cardholder_href", ((object)cardholder_href) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@cardholder_id", ((object)cardholder_id) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@cardholder_name", ((object)cardholder_name) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@cardholder_firstName", ((object)cardholder_firstName) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@cardholder_lastName", ((object)cardholder_lastName) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@entryAccessZone_href", ((object)entryAccessZone_href) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@entryAccessZone_name", ((object)entryAccessZone_name) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@entryAccessZone_id", ((object)entryAccessZone_id) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@exitAccessZone_href", ((object)exitAccessZone_href) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@exitAccessZone_name", ((object)exitAccessZone_name) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@exitAccessZone_id", ((object)exitAccessZone_id) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@door_name", ((object)door_name) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@door_id", ((object)door_id) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@card_facilityCode", ((object)card_facilityCode) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@card_number", ((object)card_number) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@card_issueLevel", ((object)card_issueLevel) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@lastOccurrenceTime", ((object)dataEvent.lastOccurrenceTime) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@Operator_cardholderID", ((object)Operator_cardholder_id) ?? DBNull.Value);
                                            sqlcmd.Parameters.AddWithValue("@AccessGrp_cardholderID", ((object)AccessGroup_cardholder_id) ?? DBNull.Value);

                                            //foreach (SqlParameter Parameter in sqlcmd.Parameters)
                                            //{
                                            //    if (Parameter.Value == null)
                                            //    {
                                            //        Parameter.Value = DBNull.Value;
                                            //    }
                                            //}
                                            SqlCommand sqlcmd2 = new SqlCommand("SELECT count(*) FROM dbo.GAL_Event where id = '" + dataEvent.id + "' and Tower = '" + Tower + "'", sql);
                                            int count = (int)sqlcmd2.ExecuteScalar();
                                            if (count > 0) { sql.Close(); }
                                            else
                                            {
                                                sqlcmd.ExecuteNonQuery();
                                                sql.Close();
                                            }
                                        }
                                        cardholderManagement.logger.Info("Event - " + dataEvent.id + " is get Successfully!");
                                        responseID.Dispose();
                                    }
                                    else
                                    {
                                        cardholderManagement.logger.Error("Failed to get event records!" + responseEvent.ReasonPhrase);
                                    }
                                }
                            }*/

                            foreach (eventConfig e in dataID.events)
                            {
                                event_id.Add(e.id);
                                cardholderManagement.logger.Info("New Event ID: " + e.id);
                            }
                            if (Regex.IsMatch(resultEvent, "\"next\""))
                            {
                                currentHref = "/" + dataID.next.href.Split('/')[3] + "/" + dataID.next.href.Split('/')[4];
                                cardholderManagement.logger.Info("next:" + currentHref);
                            }
                        }
                    }
                    else
                    {
                        cardholderManagement.logger.Error("Failure in getting Event ID!" + responseID.ReasonPhrase);
                        return;
                    }
                } while (num_of_event > 0);

                if (event_id.Count > 0)
                {
                    for (int i = 0; i < event_id.Count; i++)
                    {
                        //HttpResponseMessage responseEvent;
                        //using (Authentication._client())
                        //{
                        //    responseEvent = await Authentication._client().GetAsync("/api/events/" + event_id[i]);
                        //}
                        HttpResponseMessage responseEvent = await Authentication._client().GetAsync("/api/events/" + event_id[i]);
                        if (responseEvent.IsSuccessStatusCode)
                        {
                            string resultEvent1 = await responseEvent.Content.ReadAsStringAsync();
                            var dataEvent = JsonConvert.DeserializeObject<Example>(resultEvent1);
                            cardholderManagement.logger.Info("Get Events:" + resultEvent1);
                            if (Regex.IsMatch(resultEvent1, "\"alarm\""))
                            {
                                alarm_href = dataEvent.alarm.href;
                                alarm_state = dataEvent.alarm.state;
                            }
                            else
                            {
                                alarm_href = null;
                                alarm_state = null;
                            }

                            if (Regex.IsMatch(resultEvent1, "\"cardholder\""))
                            {
                                cardholder_href = dataEvent.cardholder.href;
                                cardholder_id = dataEvent.cardholder.id;
                                cardholder_name = dataEvent.cardholder.name;
                                cardholder_firstName = dataEvent.cardholder.firstName;
                                cardholder_lastName = dataEvent.cardholder.lastName;
                            }
                            else
                            {
                                cardholder_href = null;
                                cardholder_id = null;
                                cardholder_name = null;
                                cardholder_firstName = null;
                                cardholder_lastName = null;
                            }

                            if (Regex.IsMatch(resultEvent1, "\"entryAccessZone\""))
                            {
                                entryAccessZone_href = dataEvent.entryAccessZone.href;
                                entryAccessZone_name = dataEvent.entryAccessZone.name;
                                entryAccessZone_id = dataEvent.entryAccessZone.id;
                            }
                            else
                            {
                                entryAccessZone_href = null;
                                entryAccessZone_name = null;
                                entryAccessZone_id = null;
                            }

                            if (Regex.IsMatch(resultEvent1, "\"exitAccessZone\""))
                            {
                                exitAccessZone_href = dataEvent.exitAccessZone.href;
                                exitAccessZone_name = dataEvent.exitAccessZone.name;
                                exitAccessZone_id = dataEvent.exitAccessZone.id;
                            }
                            else
                            {
                                exitAccessZone_href = null;
                                exitAccessZone_name = null;
                                exitAccessZone_id = null;
                            }

                            if (Regex.IsMatch(resultEvent1, "\"door\""))
                            {
                                door_name = dataEvent.door.name;
                                door_id = dataEvent.door.href.ToString().Split('/')[5];
                            }
                            else
                            {
                                door_name = null;
                                door_id = null;
                            }

                            if (Regex.IsMatch(resultEvent1, "\"card\""))
                            {
                                card_facilityCode = dataEvent.card.facilityCode;
                                card_number = dataEvent.card.number;
                                card_issueLevel = dataEvent.card.issueLevel.ToString();
                            }
                            else
                            {
                                card_facilityCode = null;
                                card_number = null;
                                card_issueLevel = null;
                            }

                            if (Regex.IsMatch(resultEvent1, "\"operator\""))
                            {
                                Operator_cardholder_id = dataEvent.operator2.href.ToString().Split('/')[5];
                            }
                            else
                            {
                                Operator_cardholder_id = null;
                            }

                            if (Regex.IsMatch(resultEvent1, "\"accessGroup\""))
                            {
                                AccessGroup_cardholder_id = dataEvent.accessGroup.href.ToString().Split('/')[5];
                            }
                            else
                            {
                                AccessGroup_cardholder_id = null;
                            }

                            CultureInfo culture = new CultureInfo("zh-HK");
                            DateTime tempDate = Convert.ToDateTime(dataEvent.time, culture);
                            string date = tempDate.ToString("yyyy-MM-dd HH:mm:ss.fff");

                            if (sql.State == ConnectionState.Closed)
                                sql.Open();

                            using (SqlCommand sqlcmd = new SqlCommand("Insert into dbo.GAL_Event VALUES(@Tower,@href,@id,@time,@message,@occurrences,@priority,@alarm_href,@alarm_state,@details,@source_href,@source_id,@source_name,@group_id,@group_name,@type_id,@type_name,@division_id,@division_href,@cardholder_href,@cardholder_id,@cardholder_name,@cardholder_firstName,@cardholder_lastName,@entryAccessZone_href,@entryAccessZone_name,@entryAccessZone_id,@exitAccessZone_href,@exitAccessZone_name,@exitAccessZone_id,@door_name,@door_id,@card_facilityCode,@card_number,@card_issueLevel,@lastOccurrenceTime,@Operator_cardholderID,@AccessGrp_cardholderID)", sql))
                            {
                                sqlcmd.Parameters.AddWithValue("@Tower", ((object)Tower) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@href", ((object)dataEvent.href) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@id", ((object)dataEvent.id) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@time", ((object)date) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@message", ((object)dataEvent.message) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@occurrences", ((object)dataEvent.occurrences.ToString()) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@priority", ((object)dataEvent.priority.ToString()) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@alarm_href", ((object)alarm_href) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@alarm_state", ((object)alarm_state) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@details", ((object)dataEvent.details) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@source_href", ((object)dataEvent.source.href) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@source_id", ((object)dataEvent.source.id) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@source_name", ((object)dataEvent.source.name) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@group_id", ((object)dataEvent.group.id) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@group_name", ((object)dataEvent.group.name) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@type_id", ((object)dataEvent.type.id) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@type_name", ((object)dataEvent.type.name) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@division_id", ((object)dataEvent.division.id) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@division_href", ((object)dataEvent.division.href) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@cardholder_href", ((object)cardholder_href) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@cardholder_id", ((object)cardholder_id) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@cardholder_name", ((object)cardholder_name) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@cardholder_firstName", ((object)cardholder_firstName) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@cardholder_lastName", ((object)cardholder_lastName) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@entryAccessZone_href", ((object)entryAccessZone_href) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@entryAccessZone_name", ((object)entryAccessZone_name) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@entryAccessZone_id", ((object)entryAccessZone_id) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@exitAccessZone_href", ((object)exitAccessZone_href) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@exitAccessZone_name", ((object)exitAccessZone_name) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@exitAccessZone_id", ((object)exitAccessZone_id) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@door_name", ((object)door_name) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@door_id", ((object)door_id) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@card_facilityCode", ((object)card_facilityCode) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@card_number", ((object)card_number) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@card_issueLevel", ((object)card_issueLevel) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@lastOccurrenceTime", ((object)dataEvent.lastOccurrenceTime) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@Operator_cardholderID", ((object)Operator_cardholder_id) ?? DBNull.Value);
                                sqlcmd.Parameters.AddWithValue("@AccessGrp_cardholderID", ((object)AccessGroup_cardholder_id) ?? DBNull.Value);

                                //foreach (SqlParameter Parameter in sqlcmd.Parameters)
                                //{
                                //    if (Parameter.Value == null)
                                //    {
                                //        Parameter.Value = DBNull.Value;
                                //    }
                                //}
                                SqlCommand sqlcmd2 = new SqlCommand("SELECT count(*) FROM dbo.GAL_Event where id = '" + dataEvent.id + "' and Tower = '" + Tower + "'", sql);
                                int count = (int)sqlcmd2.ExecuteScalar();
                                if (count > 0) { sql.Close(); }
                                else
                                {
                                    sqlcmd.ExecuteNonQuery();
                                    sql.Close();
                                }
                            }
                            cardholderManagement.logger.Info("Event - " + dataEvent.id + " is get Successfully!");
                            
                        }
                        else
                        {
                            cardholderManagement.logger.Error("Failed to get event records!" + responseEvent.ReasonPhrase);
                        }
                    }
                }

            }
            catch (Exception err)
            {
                 cardholderManagement.logger.Error(err, "Failed to get event records!(big loop)");
            }
            finally
            {

            }
        }

    }
}
