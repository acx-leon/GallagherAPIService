﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GallagherAPIService
{
    public class createCardholderConfigforadd
    {
        [JsonProperty("firstName")]
        public string firstName { get; set; }

        [JsonProperty("lastName")]
        public string lastName { get; set; }

        [JsonProperty("authorised")]
        public bool authorised { get; set; }

        [JsonProperty("division")]
        public cardholderDivisionConfig division { get; set; }

        [JsonProperty("accessGroups")]
        public List<accessGrpsConfigforadd> accessGroups { get; set; }

        [JsonProperty("notifications")]
        public notificationConfig notifications { get; set; }

        [JsonProperty("cards")]
        public List<cardsConfigforadd> cards { get; set; }
    }

    public class createCardholderConfig
    {
        [JsonProperty("id")]
        public string id { get; set; }

        [JsonProperty("firstName")]
        public string firstName { get; set; }

        [JsonProperty("lastName")]
        public string lastName { get; set; }

        [JsonProperty("authorised")]
        public bool authorised { get; set; }

        [JsonProperty("division")]
        public cardholderDivisionConfig division { get; set; }

        [JsonProperty("accessGroups")]
        public List<accessGrpsConfig> accessGroups { get; set; }

        [JsonProperty("notifications")]
        public notificationConfig notifications { get; set; }

        [JsonProperty("cards")]
        public List<cardsConfig> cards { get; set; }
    }

    public class cardholderDivisionConfig
    {
        [JsonProperty("href")]
        public string href { get; set; }
    }

    public class accessGrpsConfig
    {
        [JsonProperty("href")]
        public string href { get; set; }

        [JsonProperty("accessGroup")]
        public accessGrpConfig accessGroup { get; set; }

        [JsonProperty("status")]
        public accessGrpStatus status { get; set; }
    }

    public class accessGrpsConfigforadd
    {
        [JsonProperty("accessGroup")]
        public accessGrpConfig accessGroup { get; set; }

        [JsonProperty("status")]
        public accessGrpStatus status { get; set; }
    }

    public class accessGrpConfig
    {
        [JsonProperty("name")]
        public string name { get; set; }

        [JsonProperty("href")]
        public string href { get; set; }
    }

    public class accessGrpStatus
    {
        [JsonProperty("value")]
        public string value { get; set; }

        [JsonProperty("type")]
        public string type { get; set; }
    }

    public class notificationConfig
    {
        [JsonProperty("enabled")]
        public bool enabled { get; set; }
    }

    public class cardsConfig
    {
        [JsonProperty("href")]
        public string href { get; set; }

        [JsonProperty("type")]
        public cardTypeConfig type { get; set; }

        [JsonProperty("number")]
        public string number { get; set; }

        [JsonProperty("from")]
        public string from { get; set; }

        [JsonProperty("until")]
        public string until { get; set; }

        [JsonProperty("issueLevel")]
        public string issueLv { get; set; }
    }

    public class cardsConfigforadd
    {
        [JsonProperty("type")]
        public cardTypeConfigforadd type { get; set; }

        [JsonProperty("number")]
        public string number { get; set; }

        [JsonProperty("from")]
        public string from { get; set; }

        [JsonProperty("until")]
        public string until { get; set; }
    }

    public class cardTypeConfig
    {
        [JsonProperty("href")]
        public string href { get; set; }

        [JsonProperty("name")]
        public string name { get; set; }
    }
    public class cardTypeConfigforadd
    {
        [JsonProperty("href")]
        public string href { get; set; }
    }

    public class AllAccessGrpConfig
    {
        [JsonProperty("results")]
        public List<resultsConfig> results { get; set; }

        [JsonProperty("next")]
        public nextConfig next { get; set; }
    }

    public class AllAccessZoneConfig
    {
        [JsonProperty("results")]
        public List<resultsConfig2> results { get; set; }

        [JsonProperty("next")]
        public nextConfig next { get; set; }
    }

    public class resultsConfig2
    {
        [JsonProperty("id")]
        public string id { get; set; }

        [JsonProperty("name")]
        public string name { get; set; }

    }

    public class resultsConfig
    {
        [JsonProperty("id")]
        public string id { get; set; }

        [JsonProperty("name")]
        public string name { get; set; }

    }

    public class nextConfig
    {
        [JsonProperty("href")]
        public string href { get; set; }
    }

    public class eventsConfig
    {
        [JsonProperty("events")]
        public List<eventConfig> events { get; set; }

        [JsonProperty("next")]
        public nextConfig next { get; set; }

    }

    public class Alarm
    {
        [JsonProperty("href")]
        public string href { get; set; }

        [JsonProperty("state")]
        public string state { get; set; }
    }

    public class Operator2
    {
        [JsonProperty("href")]
        public string href { get; set; }
    }

    public class Source
    {
        [JsonProperty("href")]
        public string href { get; set; }

        [JsonProperty("id")]
        public string id { get; set; }

        [JsonProperty("name")]
        public string name { get; set; }
    }

    public class Group
    {
        [JsonProperty("id")]
        public string id { get; set; }

        [JsonProperty("name")]
        public string name { get; set; }
    }

    public class Type
    {
        [JsonProperty("id")]
        public string id { get; set; }

        [JsonProperty("name")]
        public string name { get; set; }
    }

    public class Division
    {
        [JsonProperty("id")]
        public string id { get; set; }

        [JsonProperty("href")]
        public string href { get; set; }
    }

    public class Cardholder
    {
        [JsonProperty("href")]
        public string href { get; set; }

        [JsonProperty("id")]
        public string id { get; set; }

        [JsonProperty("name")]
        public string name { get; set; }

        [JsonProperty("firstName")]
        public string firstName { get; set; }

        [JsonProperty("lastName")]
        public string lastName { get; set; }
    }

    public class EntryAccessZone
    {
        [JsonProperty("href")]
        public string href { get; set; }

        [JsonProperty("name")]
        public string name { get; set; }

        [JsonProperty("id")]
        public string id { get; set; }
    }

    public class ExitAccessZone
    {
        [JsonProperty("href")]
        public string href { get; set; }

        [JsonProperty("name")]
        public string name { get; set; }

        [JsonProperty("id")]
        public string id { get; set; }
    }

    public class Door
    {
        [JsonProperty("href")]
        public string href { get; set; }

        [JsonProperty("name")]
        public string name { get; set; }
    }

    public class Card
    {
        [JsonProperty("facilityCode")]
        public string facilityCode { get; set; }

        [JsonProperty("number")]
        public string number { get; set; }

        [JsonProperty("issueLevel")]
        public int issueLevel { get; set; }
    }
    public class AccessGroup2
    {
        [JsonProperty("href")]
        public string href { get; set; }
    }


    public class Example
    {
        [JsonProperty("href")]
        public string href { get; set; }

        [JsonProperty("id")]
        public string id { get; set; }

        [JsonProperty("time")]
        public string time { get; set; }

        [JsonProperty("message")]
        public string message { get; set; }

        [JsonProperty("occurrences")]
        public int occurrences { get; set; }

        [JsonProperty("priority")]
        public int priority { get; set; }

        [JsonProperty("alarm")]
        public Alarm alarm { get; set; }

        [JsonProperty("operator")]
        public Operator2 operator2 { get; set; }

        [JsonProperty("details")]
        public string details { get; set; }

        [JsonProperty("source")]
        public Source source { get; set; }

        [JsonProperty("group")]
        public Group group { get; set; }

        [JsonProperty("type")]
        public Type type { get; set; }

        [JsonProperty("division")]
        public Division division { get; set; }

        [JsonProperty("cardholder")]
        public Cardholder cardholder { get; set; }

        [JsonProperty("entryAccessZone")]
        public EntryAccessZone entryAccessZone { get; set; }

        [JsonProperty("exitAccessZone")]
        public ExitAccessZone exitAccessZone { get; set; }

        [JsonProperty("door")]
        public Door door { get; set; }

        [JsonProperty("accessGroup")]
        public AccessGroup2 accessGroup { get; set; }

        [JsonProperty("card")]
        public Card card { get; set; }

        [JsonProperty("lastOccurrenceTime")]
        public string lastOccurrenceTime { get; set; }

    }

    public class eventConfig
    {
        [JsonProperty("id")]
        public string id { get; set; }

        [JsonProperty("time")]
        public string time { get; set; }

        [JsonProperty("message")]
        public string message { get; set; }

        [JsonProperty("source")]
        public eventSourceConfig source { get; set; }

        [JsonProperty("type")]
        public eventTypeConfig type { get; set; }

    }

    public class eventSourceConfig
    {
        [JsonProperty("name")]
        public string name { get; set; }
    }

    public class eventTypeConfig
    {
        [JsonProperty("name")]
        public string name { get; set; }
    }

    public class DeviceInfo
    {
        public string device_id { get; set; }
        public string device_desc { get; set; }
    }

    public class update_GAL
    {
        public string Tower { get; set; }
        public string Company_name { get; set; }
        public string cardholderID { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string cardNumber { get; set; }
        public string cardTypeName { get; set; }
        public string cardTypeID { get; set; }
        public string accessGrpName { get; set; }
        public string accessGrpID { get; set; }
        public string Action { get; set; }
        public DateTime Add_time { get; set; }
        public DateTime Success_time { get; set; }
        public string startDate { get; set; }
        public string endDate { get; set; }
    }

    public class Update
    {
        public string href { get; set; }
        public int issueLevel { get; set; }
        public string until { get; set; }
    }

    public class Cards
    {
        public IList<Update> update { get; set; }
    }

    public class AccessGroupEdit
    {
        public string href { get; set; }
    }

    public class Add
    {
        public AccessGroupEdit accessGroup { get; set; }
    }

    public class Remove
    {
        public string href { get; set; }
    }

    public class AccessGroups
    {
        public IList<Add> add { get; set; }
        public IList<Remove> remove { get; set; }
    }

    public class EditCardholder
    {
        public string firstName { get; set; }
        public string lastName { get; set; }
        public bool authorised { get; set; }
        public Cards cards { get; set; }
        public AccessGroups accessGroups { get; set; }
    }
}
