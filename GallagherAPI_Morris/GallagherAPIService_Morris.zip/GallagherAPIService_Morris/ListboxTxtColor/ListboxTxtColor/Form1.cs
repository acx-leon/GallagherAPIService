﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ListboxTxtColor
{
    public partial class Form1 : Form
    {
        Color myColor;
       
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            myColor = Color.Black;
            fillList();
        }

        public void fillList()
        {
            listView1.Items.Add("red");
            listView1.Items.Add("blue");
            listView1.Items.Add("green");
            listView1.Items.Add("pink");
        }

     

        private void label1_Click(object sender, EventArgs e)
        {

            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                myColor = colorDialog1.Color;
                label1.BackColor = myColor;
            }
        }

        private void listView1_ItemActivate(object sender, EventArgs e)
        {
            listView1.Items[listView1.SelectedIndices[0]].ForeColor = myColor;

        }

     
    }
}


